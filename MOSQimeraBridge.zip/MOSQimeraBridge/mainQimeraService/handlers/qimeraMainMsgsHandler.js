// handlers/qimeraMainMsgsHandler.js
const webSocketManager = require('../services/webSocketManager');
const tcpServer = require('../services/tcpServer');


// This class handles messages coming from the QimetraApp instances.
// It processes the messages and routes them to the appropriate web clients and sends responses back to the QimeraApp instances.
class QimeraMainMsgsHandler {
  handle(instanceId, message) {

    console.log(`Processing trigger for instance: ${instanceId}, message: ${JSON.stringify(message)}`);

    // TODO: Handle data for the data base service

    // Add instanceId to the message
    message.instanceId = instanceId;

    // Broadcast message to all web clients via WebSocket
    webSocketManager.sendToClients(message);

    // Send a response message to the relevant QimeraApp instance via TCP
    const response = {
      type: 'ack',
      data: 'Message received'
    };
    tcpServer.sendToApp(instanceId, response);
  }
}

module.exports = new QimeraMainMsgsHandler();