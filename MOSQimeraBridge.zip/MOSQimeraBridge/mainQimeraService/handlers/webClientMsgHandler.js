
const tcpServer = require('../services/tcpServer');


// This class handles messages from the web clients to the QimeraApp instances.
// It routes the messages to the appropriate QimeraApp instance via TCP.
class WebClientMsgHandler {
    handle(instanceId, message) {
        console.log(`Processing message for instance: ${instanceId}, message: ${JSON.stringify(message)}`);

        tcpServer.sendToApp(instanceId, message);
    }
}

module.exports = new WebClientMsgHandler();