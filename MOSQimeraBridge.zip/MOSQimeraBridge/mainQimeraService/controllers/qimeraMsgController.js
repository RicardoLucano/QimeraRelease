const { logger } = require('../../shared/utils/logger');
const compositionMsgController = require('./compositionMsgController');

const receiveQimeraMsgHandler = (qimeraMessage) => {
    // Process the qimera data here
    logger.info('Qimera message received');
    logger.debug(JSON.stringify(qimeraMessage));

    // Get type of data
    const action = qimeraMessage.action;
    const module = qimeraMessage.module;

    // Process data based on type
    switch (module) {
        case 'compositionData':
            compositionMsgController.compositionMsgHandler(qimeraMessage.moduleData, action);
            break;
        default:
            logger.error('Unknown data type:', module);
            break;
    }
}

const sendQimeraMsgHandler = (messageToSend) => {
    // Send the message to the Qimera service
    logger.info('Sending Qimera message');
    logger.debug(JSON.stringify(messageToSend));

    // Send the message to the Qimera service
    // For example, using a WebSocket connection
    // ws.send(JSON.stringify(messageToSend));
}

module.exports = {
    receiveQimeraMsgHandler
};
