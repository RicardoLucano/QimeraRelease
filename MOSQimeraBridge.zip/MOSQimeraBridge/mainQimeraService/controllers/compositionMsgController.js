const { logger } = require('../../shared/utils/logger');

// Composition data model
const compositionDataModel = require('../models/compositionDataModel');

const compositionMsgHandler = (compositionData, action) => {
    // Process the composition data here
    logger.info('Composition data received');
    logger.debug(JSON.stringify(compositionData));

    // Get type of data
    const type = compositionData.type
    const data = compositionData.data

    // Process data based on type
    switch (type) {
        case 'sceneData':
            sceneDataHandler(data, action);
            break;
        case 'panelData':
            panelDataHandler(data, action);
            break;
        case 'triggerData':
            triggerDataHandler(data, action);
            break;
        default:
            logger.error('Unknown data type:', type);
            break;
    }
}

const sceneDataHandler = (sceneData, action) => {
    // Process the scene data here
    logger.info('Scene data received');
    logger.debug(JSON.stringify(sceneData));

    // Process the action
    switch (action) {
        case 'add':
            compositionDataModel.addScene(sceneData);
            break;
        case 'delete':
            compositionDataModel.deleteScene(sceneData);
            break;
        case 'set':
            compositionDataModel.setScenes(sceneData.scenes);
            break;
        case 'deleteAll':
            compositionDataModel.deleteScenes();
            break;
        default:
            logger.error('Unknown action:', action);
            break;
    }
}

const panelDataHandler = (panelData, action) => {
    // Process the panel data here
    logger.info('Panel data received');
    logger.debug(JSON.stringify(panelData));

    // Process the action
    switch (action) {
        case 'add':
            compositionDataModel.addPanel(panelData);
            break;
        case 'delete':
            compositionDataModel.deletePanel(panelData);
            break;
        case 'set':
            compositionDataModel.setPanels(panelData.panels);
            break;
        case 'deleteAll':
            compositionDataModel.deletePanels();
            break;
        default:
            logger.error('Unknown action:', action);
            break;
    }
}

const triggerDataHandler = (triggerData, action) => {
    // Process the trigger data here
    logger.info('Trigger data received');
    logger.debug(JSON.stringify(triggerData));

    // Process the action
    switch (action) {
        case 'add':
            compositionDataModel.addTrigger(triggerData);
            break;
        case 'delete':
            compositionDataModel.deleteTrigger(triggerData);
            break;
        case 'set':
            compositionDataModel.setTriggers(triggerData.triggers);
            break;
        case 'deleteAll':
            compositionDataModel.deleteTriggers();
            break;
        default:
            logger.error('Unknown action:', action);
            break;
    }
}

module.exports = {
    compositionMsgHandler
};