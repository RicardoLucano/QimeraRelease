// mainQimeraService/controllers/authController.js
const jwt = require('jsonwebtoken');

const users = {
    'admin': { password: '1234' }, // Example user
}; // In-memory user storage for simplicity

exports.login = (req, res) => {
    const { username, password } = req.body;
    if (users[username] && users[username].password === password) {
        const token = jwt.sign({ username }, 'secretKey', { expiresIn: '1h' });
        res.json({ token });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
};

// Future implementation: Uses external authentication service
