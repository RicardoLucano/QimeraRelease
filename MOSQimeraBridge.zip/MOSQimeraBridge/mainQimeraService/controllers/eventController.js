// mainQimeraService/controllers/eventController.js
const wsService = require('../services/wsService');

const handleTriggerEvent = (req, res) => {
    const { eventType, data } = req.body; // Assume eventType and data are sent in the body
    // Broadcast the event to connected QimeraApp instances
    wsService.broadcastEvent(eventType, data);
    res.status(200).send('Event processed');
};

module.exports = { handleTriggerEvent };
