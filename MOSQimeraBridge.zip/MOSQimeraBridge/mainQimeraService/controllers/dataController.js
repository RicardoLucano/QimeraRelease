// mainQimeraService/controllers/dataController.js
const tcpService = require('../services/tcpService');

exports.receiveData = (req, res) => {
    const data = req.body;
    // Handle received data (save, process, etc.)
    tcpService.sendDataToClients(data);
    res.status(200).send('Data received');
};
