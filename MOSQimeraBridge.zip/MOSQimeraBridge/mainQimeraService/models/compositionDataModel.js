
let compositionData = {
    scenes: [],
    panels: [],
    triggers: []
};

const getCompositionData = () => {
    return compositionData;
};

// Add a new scene to the composition data
const addScene = (sceneData) => {
    
    // Check if the scene already exists
    const sceneIndex = compositionData.scenes.findIndex(scene => scene.sceneID === sceneData.sceneID);
    if (sceneIndex !== -1) {
        console.log('Scene already exists:', sceneData.sceneID);
        
        // Update the existing scene
        compositionData.scenes[sceneIndex] = sceneData;
        return;
    }

    // Add the new scene
    compositionData.scenes.push(sceneData);
};

// Delete a scene from the composition data
const deleteScene = (sceneID) => {
    // Find the scene index
    const sceneIndex = compositionData.scenes.findIndex(scene => scene.sceneID === sceneID);
    if (sceneIndex === -1) {
        console.log('Scene not found:', sceneID);
        return;
    }

    // Remove the scene
    compositionData.scenes.splice(sceneIndex, 1);
};

// Set all scenes in the composition data
const setScenes = (scenes) => {
    compositionData.scenes = scenes;
};

// delete all scenes in the composition data
const deleteScenes = () => {
    compositionData.scenes = [];
};


// Add a new panel to the composition data
const addPanel = (panelData) => {
    
    // Check if the panel already exists
    const panelIndex = compositionData.panels.findIndex(panel => panel.panelID === panelData.panelID);
    if (panelIndex !== -1) {
        console.log('Panel already exists:', panelData.panelID);
        
        // Update the existing panel
        compositionData.panels[panelIndex] = panelData;
        return;
    }

    // Add the new panel
    compositionData.panels.push(panelData);
};

// Delete a panel from the composition data
const deletePanel = (panelID) => {
    // Find the panel index
    const panelIndex = compositionData.panels.findIndex(panel => panel.panelID === panelID);
    if (panelIndex === -1) {
        console.log('Panel not found:', panelID);
        return;
    }

    // Remove the panel
    compositionData.panels.splice(panelIndex, 1);
};

// Set all panels in the composition data
const setPanels = (panels) => {
    compositionData.panels = panels;
};

// delete all panels in the composition data
const deletePanels = () => {
    compositionData.panels = [];
};


// Add a new trigger to the composition data
const addTrigger = (triggerData) => {
    
    // Check if the trigger already exists
    const triggerIndex = compositionData.triggers.findIndex(trigger => trigger.triggerID === triggerData.triggerID);
    if (triggerIndex !== -1) {
        console.log('Trigger already exists:', triggerData.triggerID);
        
        // Update the existing trigger
        compositionData.triggers[triggerIndex] = triggerData;
        return;
    }

    // Add the new trigger
    compositionData.triggers.push(triggerData);
};

// Delete a trigger from the composition data
const deleteTrigger = (triggerID) => {
    // Find the trigger index
    const triggerIndex = compositionData.triggers.findIndex(trigger => trigger.triggerID === triggerID);
    if (triggerIndex === -1) {
        console.log('Trigger not found:', triggerID);
        return;
    }

    // Remove the trigger
    compositionData.triggers.splice(triggerIndex, 1);
};

// Set all triggers in the composition data
const setTriggers = (triggers) => {
    compositionData.triggers = triggers;
};

// delete all triggers in the composition data
const deleteTriggers = () => {
    compositionData.triggers = [];
};


module.exports = {
    getCompositionData,
    addScene,
    deleteScene,
    setScenes,
    deleteScenes,
    addPanel,
    deletePanel,
    setPanels,
    deletePanels,
    addTrigger,
    deleteTrigger,
    setTriggers,
    deleteTriggers
};