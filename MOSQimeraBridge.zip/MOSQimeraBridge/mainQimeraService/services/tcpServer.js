const net = require('net');
const dataStore = require('./dataStore');
const messageRouter = require('./messageRouter');

const clients = {}; // Store QimeraApp instances by instanceId

function sendInstanceListToRouter(instanceId) {
  // Send the connected instaces to the web     
  const allInstancesData = dataStore.getAllInstancesData();
  const moduleData = {subModule: 'allInstances', data: allInstancesData};
  const allInstancesMsg = {type: 'set', module: 'generalData', moduleData: moduleData};
  messageRouter.routeMessage(instanceId, 'qimeraMainMsgs', allInstancesMsg);
}

// This function is called when a new instance connects
function addInstanceFromSocket(socket) {
  const instanceId = socket.socketName;
  clients[instanceId] = socket;
  dataStore.addInstance(instanceId, { connectedAt: Date.now() });
  console.log(`QimeraApp instance <${instanceId}> connected`);

  // Send the connected instances to the web
  sendInstanceListToRouter(instanceId);
}

function getInstanceFromSocket(socket) {
  if (!socket) {
    console.error('Socket is undefined or null');
    return null;
  }
  const instanceId = Object.keys(clients).find(key => clients[key] === socket);
  if (!instanceId) {
    console.error('Instance ID not found for the given socket');
    return null;
  }
  return instanceId;
}

function createTcpServer() {
  const startServer = (port = 10540) => {
    const server = net.createServer(socket => {
      let buffer = ''; // Buffer to accumulate data

      socket.once('data', (data) => {
        const socketName = data.toString().trim();
        console.log(`Socket Name Received: ${socketName}`);
        socket.socketName = socketName;
        addInstanceFromSocket(socket);
      });

      socket.on('data', (data) => {
        buffer += data.toString(); // Append incoming data to buffer

        let newlineIndex;
        // Process all complete messages (delimited by newline)
        while ((newlineIndex = buffer.indexOf('\n')) !== -1) {
          const rawMessage = buffer.slice(0, newlineIndex).trim();
          buffer = buffer.slice(newlineIndex + 1); // Remove processed part

          if (rawMessage.length === 0) continue; // Skip empty lines

          try {
            const message = JSON.parse(rawMessage);
            const instanceId = getInstanceFromSocket(socket);
            if (instanceId) {
              messageRouter.routeMessage(instanceId, 'qimeraMainMsgs', message);
            }
          } catch (error) {
            console.error('Error parsing message:', error);
            console.log('Invalid JSON:', rawMessage);
          }
        }
      });

      socket.on('close', () => {
        console.log(`QimeraApp instance ${socket.socketName} disconnected`);
        const instanceId = getInstanceFromSocket(socket);
        dataStore.removeInstance(instanceId);
        delete clients[instanceId];

        // Send the connected instances to the web
        sendInstanceListToRouter(instanceId);
      });

      socket.on('error', (err) => {
        console.error(`Socket error: ${err.message}`);
      });
    });

    server.listen(port, () => {
      console.log(`TCP server running on port ${port}`);
    });
  };

  const sendToApp = (instanceId, message) => {
    const client = clients[instanceId];
    if (!client) {
      console.error(`Client <${instanceId}> not found`);
      return;
    }
    const messageStr = JSON.stringify(message) + '\n';
    console.log(`Sending message to <${instanceId}>`);
    client.write(messageStr);
  };

  return {
    startServer,
    sendToApp
  };
}

module.exports = createTcpServer();
