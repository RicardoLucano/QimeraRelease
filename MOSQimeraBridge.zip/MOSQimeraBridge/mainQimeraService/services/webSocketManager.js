// services/webSocketManager.js
const WebSocket = require('ws');
const dataStore = require('./dataStore');
const messageRouter = require('./messageRouter');

class WebSocketManager {
  constructor() {
    this.clients = [];
  }

  startServer(port = 8080) {
    this.server = new WebSocket.Server({ port });

    // On new connection
    // Add the new client to the list of clients and log the connection
    this.server.on('connection', ws => {
      this.clients.push(ws);
      console.log('Web client connected');

      const allInstancesData = dataStore.getAllInstancesData();

      const moduleData = {subModule: 'allInstances', data: allInstancesData};
      const allInstancesMsg = {type: 'set', module: 'generalData', moduleData: moduleData};
      ws.send(JSON.stringify(allInstancesMsg));

      // On receiving a message from the web client
      // Parse the message and route it to the appropriate handler
      ws.on('message', message => {
        const parsedMessage = JSON.parse(message);
        console.log('Received message:', parsedMessage);
        const instanceId = parsedMessage.instanceId;    
        messageRouter.routeMessage(instanceId,'webClient', parsedMessage);
      });

      // On client disconnection
      // Remove the client from the list and log the disconnection
      ws.on('close', () => {
        this.clients = this.clients.filter(client => client !== ws);
        console.log('Web client disconnected');
      });
    });

    console.log(`WebSocket server running on port ${port}`);
  }

  // Send a message to all connected web clients that consumes the qimera main services
  sendToClients(message) {
    this.clients.forEach(client => {
      client.send(JSON.stringify(message));
    });
  }

  // Broadcast instance data to all clients
  broadcastInstanceData(instanceId) {
    const instanceData = dataStore.getInstanceData(instanceId);
    if (instanceData) {
      this.sendToClients({ type: 'instanceUpdate', instanceId, data: instanceData });
    }
  }
}

module.exports = new WebSocketManager();
