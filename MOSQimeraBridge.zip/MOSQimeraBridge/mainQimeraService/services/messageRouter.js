// services/messageRouter.js
const dataStore = require('./dataStore');
class MessageRouter {
  constructor() {
    this.handlers = {};
  }

  registerHandler(tag, handler) {
    this.handlers[tag] = handler;
  }

  routeMessage(instanceId, tag, message) {

    if (this.handlers[tag]) {
      this.handlers[tag].handle(instanceId, message);
    } else {
      console.warn(`No handler for message type: ${tag}`);
    }
  }
}

const messageRouter = new MessageRouter();
module.exports = messageRouter;
