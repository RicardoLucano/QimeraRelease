// services/dataStore.js

class DataStore {
    constructor() {
      // In-memory data store for QimeraApp instances
      this.instances = {};
    }
  
    // Register new instance data
    addInstance(instanceId, data = {}) {
      this.instances[instanceId] = { ...data, id: instanceId, name: instanceId, lastUpdated: Date.now()};
    }
  
    // Update instance data (e.g., triggers, scenes, etc.)
    updateInstanceData(instanceId, key, value) {
      if (this.instances[instanceId]) {
        this.instances[instanceId][key] = value;
        this.instances[instanceId].lastUpdated = Date.now();
      }
    }
  
    // Get data for a specific instance
    getInstanceData(instanceId) {
      return this.instances[instanceId] || null;
    }
  
    // Remove an instance (e.g., on disconnect)
    removeInstance(instanceId) {
      delete this.instances[instanceId];
    }
  
    // Get array of all instances (e.g., to display in UI)
    getAllInstancesData() {
      // Return array of instances
      return Object.values(this.instances);
    }
  }
  
  module.exports = new DataStore();
  