// services/mainQimeraService.js
const messageRouter = require('./services/messageRouter');
const tcpServer = require('./services/tcpServer');
const webSocketManager = require('./services/webSocketManager');


const qimeraMainMsgsHandler = require('./handlers/qimeraMainMsgsHandler');
const webClientMsgHandler = require('./handlers/webClientMsgHandler');

const {MAIN_QIMERA_TCP_PORT, MAIN_WS_PORT} = require('./../shared/appConfig');

// Register message handlers
messageRouter.registerHandler('qimeraMainMsgs', qimeraMainMsgsHandler); // Can register more handlers here
messageRouter.registerHandler('webClient', webClientMsgHandler);

// Start TCP server for QimeraApp connections
tcpServer.startServer(MAIN_QIMERA_TCP_PORT);

// Start WebSocket server for real-time updates
webSocketManager.startServer(MAIN_WS_PORT);
