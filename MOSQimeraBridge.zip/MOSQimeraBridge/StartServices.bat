@echo off
echo.
echo Starting all services...

echo This script will start the mainQimeraService, webClient, and ro services using PM2 in WSL.
echo Make sure you have WSL and Node.js installed in your WSL environment.
echo.

:: Check for WSL
where wsl >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] WSL is not installed.
    echo Please install WSL from: https://docs.microsoft.com/en-us/windows/wsl/install
    pause
    exit /b
)

:: Check if Node.js is installed in WSL
echo Checking for Node.js in WSL...
wsl node -v >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not installed in your WSL environment.
    echo You must install Node.js inside WSL before continuing.
    echo You can do this inside WSL with: curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt install -y nodejs
    pause
    exit /b
)

:: Check if NPM is installed in WSL
echo Checking for NPM in WSL...
wsl npm -v >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] npm is not installed in your WSL environment.
    echo Please install npm by reinstalling Node.js inside WSL.
    pause
    exit /b
)

:: Check for PM2 inside WSL
echo Checking for PM2 in WSL...
wsl pm2 -v >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo PM2 not found. Installing PM2 globally in WSL...
    wsl sudo npm install -g pm2
    wsl pm2 -v
)

:: Install frontend dependencies
echo Installing frontend dependencies...
pushd mosQimeraPlugin\frontend
wsl npm install
wsl npx update-browserslist-db@latest
wsl -d Ubuntu -- bash -c "cd mosQimeraPlugin/frontend && npm install xml2js xmlbuilder"
wsl -d Ubuntu -- bash -c "cd mosQimeraPlugin/frontend && npm audit fix --force"

if !errorlevel! neq 0 (
    echo Failed to install frontend dependencies.
    popd
)
popd
echo Frontend dependencies installed successfully.


:: Start services using PM2
echo Starting services with PM2...
wsl pm2 start ecosystem.config.js

echo.
echo All services checked and started where necessary.
timeout /t 2 /nobreak >nul
