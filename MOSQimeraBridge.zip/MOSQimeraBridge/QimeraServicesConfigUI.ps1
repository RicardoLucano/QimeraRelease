Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# -------------------------------
# Function: Add validation to port fields
# -------------------------------
# TODO: Implement the validation logic for port fields
function Add-PortValidation {
    param (
        [System.Windows.Forms.TextBox]$textBox,
        [string]$fieldName = "Port"
    )
}

# Create Form
$form = New-Object System.Windows.Forms.Form
$form.Text = "Qimera Server Configuration"
$form.Size = New-Object System.Drawing.Size(520, 500)
$form.StartPosition = "CenterScreen"

# Create Tab Control
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Dock = "Fill"

# --------------------
# Tab 1: Main Server
# --------------------
$tabQimera = New-Object System.Windows.Forms.TabPage
$tabQimera.Text = "Main Server"

$labelDescription = New-Object System.Windows.Forms.Label
$labelDescription.Text = "Configure the server port used by the main Qimera instance."
$labelDescription.Location = New-Object System.Drawing.Point(20, 10)
$labelDescription.Size = New-Object System.Drawing.Size(450, 30)
$labelDescription.ForeColor = 'DarkSlateGray'
$labelDescription.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Italic)
$tabQimera.Controls.Add($labelDescription)

$labelPort = New-Object System.Windows.Forms.Label
$labelPort.Text = "Qimera Tcp Port:"
$labelPort.Location = New-Object System.Drawing.Point(20, 50)
$labelPort.AutoSize = $true
$tabQimera.Controls.Add($labelPort)

$textTcpPort = New-Object System.Windows.Forms.TextBox
$textTcpPort.Location = New-Object System.Drawing.Point(120, 45)
$textTcpPort.Width = 200
$tabQimera.Controls.Add($textTcpPort)

$labelWsPort = New-Object System.Windows.Forms.Label
$labelWsPort.Text = "WebSocket Port:"
$labelWsPort.Location = New-Object System.Drawing.Point(20, 80)
$labelWsPort.AutoSize = $true
$tabQimera.Controls.Add($labelWsPort)

$textWsPort = New-Object System.Windows.Forms.TextBox
$textWsPort.Location = New-Object System.Drawing.Point(120, 75)
$textWsPort.Width = 200
$tabQimera.Controls.Add($textWsPort)

$tabControl.TabPages.Add($tabQimera)

# --------------------
# Tab 2: MOS Ro Service
# --------------------
$tabMos = New-Object System.Windows.Forms.TabPage
$tabMos.Text = "MOS Ro Service"

$labelMosDesc = New-Object System.Windows.Forms.Label
$labelMosDesc.Text = "Configure the MOS connection and the Qimera RO Service."
$labelMosDesc.Location = New-Object System.Drawing.Point(20, 10)
$labelMosDesc.Size = New-Object System.Drawing.Size(450, 30)
$labelMosDesc.ForeColor = 'DarkSlateGray'
$labelMosDesc.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Italic)
$tabMos.Controls.Add($labelMosDesc)

# GroupBox 1: MOS Connection
$groupMos = New-Object System.Windows.Forms.GroupBox
$groupMos.Text = "MOS Connection"
$groupMos.Location = New-Object System.Drawing.Point(20, 40)
$groupMos.Size = New-Object System.Drawing.Size(460, 120)
$tabMos.Controls.Add($groupMos)

$labelMosIp = New-Object System.Windows.Forms.Label
$labelMosIp.Text = "MOS IP:"
$labelMosIp.Location = New-Object System.Drawing.Point(10, 25)
$groupMos.Controls.Add($labelMosIp)

$textMosIp = New-Object System.Windows.Forms.TextBox
$textMosIp.Location = New-Object System.Drawing.Point(120, 22)
$textMosIp.Width = 300
$groupMos.Controls.Add($textMosIp)

$labelMosLower = New-Object System.Windows.Forms.Label
$labelMosLower.Text = "MOS LOWER PORT:"
$labelMosLower.Location = New-Object System.Drawing.Point(10, 55)
$groupMos.Controls.Add($labelMosLower)

$textMosLower = New-Object System.Windows.Forms.TextBox
$textMosLower.Location = New-Object System.Drawing.Point(120, 52)
$textMosLower.Width = 300
$groupMos.Controls.Add($textMosLower)

$labelMosUpper = New-Object System.Windows.Forms.Label
$labelMosUpper.Text = "MOS UPPER PORT:"
$labelMosUpper.Location = New-Object System.Drawing.Point(10, 85)
$groupMos.Controls.Add($labelMosUpper)

$textMosUpper = New-Object System.Windows.Forms.TextBox
$textMosUpper.Location = New-Object System.Drawing.Point(120, 82)
$textMosUpper.Width = 300
$groupMos.Controls.Add($textMosUpper)

# GroupBox 2: Qimera RO Service
$groupRo = New-Object System.Windows.Forms.GroupBox
$groupRo.Text = "Qimera RO Service"
$groupRo.Location = New-Object System.Drawing.Point(20, 170)
$groupRo.Size = New-Object System.Drawing.Size(460, 70)
$tabMos.Controls.Add($groupRo)

$labelRoPort = New-Object System.Windows.Forms.Label
$labelRoPort.Text = "Server Port:"
$labelRoPort.Location = New-Object System.Drawing.Point(10, 30)
$groupRo.Controls.Add($labelRoPort)

$textRoPort = New-Object System.Windows.Forms.TextBox
$textRoPort.Location = New-Object System.Drawing.Point(120, 27)
$textRoPort.Width = 300
$groupRo.Controls.Add($textRoPort)

$tabControl.TabPages.Add($tabMos)

# --------------------
# Tab 3: Web Services
# --------------------
$tabWeb = New-Object System.Windows.Forms.TabPage
$tabWeb.Text = "Web Services"

$labelWebDesc = New-Object System.Windows.Forms.Label
$labelWebDesc.Text = "Configure ports and URLs for Web Client and WebSocket clients."
$labelWebDesc.Location = New-Object System.Drawing.Point(20, 10)
$labelWebDesc.Size = New-Object System.Drawing.Size(450, 30)
$labelWebDesc.ForeColor = 'DarkSlateGray'
$labelWebDesc.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Italic)
$tabWeb.Controls.Add($labelWebDesc)

# GroupBox 1: Web Client
$groupWebClient = New-Object System.Windows.Forms.GroupBox
$groupWebClient.Text = "Web Client"
$groupWebClient.Location = New-Object System.Drawing.Point(20, 40)
$groupWebClient.Size = New-Object System.Drawing.Size(460, 60)
$tabWeb.Controls.Add($groupWebClient)

$labelWebPort = New-Object System.Windows.Forms.Label
$labelWebPort.Text = "Port:"
$labelWebPort.Location = New-Object System.Drawing.Point(10, 25)
$groupWebClient.Controls.Add($labelWebPort)

$textWebPort = New-Object System.Windows.Forms.TextBox
$textWebPort.Location = New-Object System.Drawing.Point(120, 22)
$textWebPort.Width = 300
$groupWebClient.Controls.Add($textWebPort)

# GroupBox 2: WS Client – Main Server
$groupWsMain = New-Object System.Windows.Forms.GroupBox
$groupWsMain.Text = "WS Client for the Main Server connection"
$groupWsMain.Location = New-Object System.Drawing.Point(20, 110)
$groupWsMain.Size = New-Object System.Drawing.Size(460, 90)
$tabWeb.Controls.Add($groupWsMain)

$labelWsUrlMain = New-Object System.Windows.Forms.Label
$labelWsUrlMain.Text = "URL:"
$labelWsUrlMain.Location = New-Object System.Drawing.Point(10, 25)
$groupWsMain.Controls.Add($labelWsUrlMain)

$textWsUrlMain = New-Object System.Windows.Forms.TextBox
$textWsUrlMain.Location = New-Object System.Drawing.Point(120, 22)
$textWsUrlMain.Width = 300
$groupWsMain.Controls.Add($textWsUrlMain)

$labelWsPortMain = New-Object System.Windows.Forms.Label
$labelWsPortMain.Text = "Port:"
$labelWsPortMain.Location = New-Object System.Drawing.Point(10, 55)
$groupWsMain.Controls.Add($labelWsPortMain)

$textWsPortMain = New-Object System.Windows.Forms.TextBox
$textWsPortMain.Location = New-Object System.Drawing.Point(120, 52)
$textWsPortMain.Width = 300
$groupWsMain.Controls.Add($textWsPortMain)

# GroupBox 3: WS Client – Qimera RO Service
$groupWsRo = New-Object System.Windows.Forms.GroupBox
$groupWsRo.Text = "WS Client for the Qimera RO Service connection"
$groupWsRo.Location = New-Object System.Drawing.Point(20, 210)
$groupWsRo.Size = New-Object System.Drawing.Size(460, 90)
$tabWeb.Controls.Add($groupWsRo)

$labelWsUrlRo = New-Object System.Windows.Forms.Label
$labelWsUrlRo.Text = "URL:"
$labelWsUrlRo.Location = New-Object System.Drawing.Point(10, 25)
$groupWsRo.Controls.Add($labelWsUrlRo)

$textWsUrlRo = New-Object System.Windows.Forms.TextBox
$textWsUrlRo.Location = New-Object System.Drawing.Point(120, 22)
$textWsUrlRo.Width = 300
$groupWsRo.Controls.Add($textWsUrlRo)

$labelWsPortRo = New-Object System.Windows.Forms.Label
$labelWsPortRo.Text = "Port:"
$labelWsPortRo.Location = New-Object System.Drawing.Point(10, 55)
$groupWsRo.Controls.Add($labelWsPortRo)

$textWsPortRo = New-Object System.Windows.Forms.TextBox
$textWsPortRo.Location = New-Object System.Drawing.Point(120, 52)
$textWsPortRo.Width = 300
$groupWsRo.Controls.Add($textWsPortRo)

$tabControl.TabPages.Add($tabWeb)

# Apply Port Validation to All Port Fields
Add-PortValidation -textBox $textTcpPort -fieldName "Qimera Tcp Port"
Add-PortValidation -textBox $textWsPort -fieldName "WebSocket Port"
Add-PortValidation -textBox $textMosLower -fieldName "MOS LOWER PORT"
Add-PortValidation -textBox $textMosUpper -fieldName "MOS UPPER PORT"
Add-PortValidation -textBox $textRoPort -fieldName "RO Service Port"
Add-PortValidation -textBox $textWebPort -fieldName "Web Client Port"
Add-PortValidation -textBox $textWsPortMain -fieldName "WS Main Server Port"
Add-PortValidation -textBox $textWsPortRo -fieldName "WS RO Service Port"

################################################################
# Buttons

# Start Services
$btnStartServices = New-Object System.Windows.Forms.Button
$btnStartServices.Text = "Start Services"
$btnStartServices.Size = New-Object System.Drawing.Size(120, 30)
$btnStartServices.Location = New-Object System.Drawing.Point(20, 420)
$btnStartServices.Add_Click({ Start-Services })
$form.Controls.Add($btnStartServices)

# Button to Stop Services
$btnStopServices = New-Object System.Windows.Forms.Button
$btnStopServices.Text = "Stop Services"
$btnStopServices.Size = New-Object System.Drawing.Size(120, 30)
$btnStopServices.Location = New-Object System.Drawing.Point(150, 420)
$btnStopServices.Add_Click({ Stop-Services })
$form.Controls.Add($btnStopServices)

# Button to Save Settings
$saveButton = New-Object System.Windows.Forms.Button
$saveButton.Text = "Save Settings"
$saveButton.Size = New-Object System.Drawing.Size(120, 30)
$saveButton.Location = New-Object System.Drawing.Point(360, 420)
$saveButton.Add_Click({ Save-Config })
$form.Controls.Add($saveButton)


# Finalize Form
$form.Controls.Add($tabControl)
$form.Topmost = $true
$form.Add_Shown({ $form.Activate() })


# Path to config file
$configFile = "$PSScriptRoot\config.json"

# Function to Start Services
function Start-Services {
    $startBat = Join-Path $PSScriptRoot "StartServices.bat"
    if (Test-Path $startBat) {
        Start-Process -FilePath $startBat -WorkingDirectory $PSScriptRoot
        [System.Windows.Forms.MessageBox]:: Show("Services started successfully!", "Success", "OK", "Information")
    } else {
        [System.Windows.Forms.MessageBox]::Show("StartServices.bat not found!", "Error", "OK", "Error")
    }
}

# Function to Stop Services
function Stop-Services {
    $stopBat = Join-Path $PSScriptRoot "StopServices.bat"
    if (Test-Path $stopBat) {
        Start-Process -FilePath $stopBat -WorkingDirectory $PSScriptRoot
        [System.Windows.Forms.MessageBox]::Show("Services stopped successfully!", "Success", "OK", "Information")
    } else {
        [System.Windows.Forms.MessageBox]::Show("StopServices.bat not found!", "Error", "OK", "Error")
    }
}

# Function to Save Config to JSON
function Save-Config {
    $config = @{
        mainService = @{
            qimeraTcpPort = $textTcpPort.Text
            wsPort = $textWsPort.Text
        }
        mos = @{
            ip = $textMosIp.Text
            lowerPort = $textMosLower.Text
            upperPort = $textMosUpper.Text
        }
        roServicePort = $textRoPort.Text
        webClientPort = $textWebPort.Text
        wsMain = @{
            url = $textWsUrlMain.Text
            port = $textWsPortMain.Text
        }
        wsRo = @{
            url = $textWsUrlRo.Text
            port = $textWsPortRo.Text
        }
    }

    $json = $config | ConvertTo-Json -Depth 4
    $json | Out-File -Encoding UTF8 -FilePath $configFile

    [System.Windows.Forms.MessageBox]::Show("Configuration saved successfully!", "Success", "OK", "Information")
}

# Function to Load Config from JSON (on startup)
function Load-Config {
    if (Test-Path $configFile) {
        $config = Get-Content $configFile | ConvertFrom-Json

        $textTcpPort.Text = $config.mainService.qimeraTcpPort
        $textWsPort.Text = $config.mainService.wsPort
        $textMosIp.Text = $config.mos.ip
        $textMosLower.Text = $config.mos.lowerPort
        $textMosUpper.Text = $config.mos.upperPort
        $textRoPort.Text = $config.roServicePort
        $textWebPort.Text = $config.webClientPort
        $textWsUrlMain.Text = $config.wsMain.url
        $textWsPortMain.Text = $config.wsMain.port
        $textWsUrlRo.Text = $config.wsRo.url
        $textWsPortRo.Text = $config.wsRo.port
    }
}

# Load config at startup
Load-Config


[void]$form.ShowDialog()
