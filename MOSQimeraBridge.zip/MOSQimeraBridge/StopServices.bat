wsl pm2 kill
@echo off

:: Stop for 2 seconds to allow the user to see the output
timeout /t 2 /nobreak >nul