// Description: Main entry point for the MOS Bridge application.
const mosRoService  = require('./services/mosRoService');
const wsService = require('./services/wsService');

const { logger } = require('./../shared/utils/logger');
const {RO_SERVER_PORT} = require('./../shared/appConfig');


logger.info('Starting the MOS RO Service...');
// Start the MOS RO Service
mosRoService.startRoService();

// Start the WebSocket service for real-time updates
wsService.startServer(RO_SERVER_PORT);