// services/webSocketManager.js
const WebSocket = require('ws');

const { logger } = require('../../shared/utils/logger');

class WebSocketManager {
  constructor() {
    this.clients = [];
  }

  startServer(port = 3003) {
    this.server = new WebSocket.Server({ port });

    this.server.on('connection', ws => {
      this.clients.push(ws);
      logger.info('Web client connected');

      ws.on('message', message => {
        const parsedMessage = JSON.parse(message);
        logger.info('Received message:', parsedMessage);
      });

      ws.on('close', () => {
        this.clients = this.clients.filter(client => client !== ws);
        logger.info('Web client disconnected');
      });
    });

    logger.info(`WebSocket server running on port ${port}`);
  }

  sendToClients(message) {
    this.clients.forEach(client => {
      client.send(JSON.stringify(message));
    });
  }
}

module.exports = new WebSocketManager();
