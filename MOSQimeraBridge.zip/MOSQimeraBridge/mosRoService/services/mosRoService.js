const net = require('net');
const mosRoController = require('../controllers/mosRoController');
const { logger } = require('../../shared/utils/logger');

const { MOS_UPPER_PORT } = require('../../shared/appConfig');

let roClients = [];  // Track RO clients connected to the Upper Port
let buffer = '';

/**
 * Start the MOS Upper Port (10541) connection for RO messages.
 */
const startRoService = () => {

    const roServer = net.createServer((socket) => {
        logger.info(`New connection on Upper Port (RO) from: ${socket.remoteAddress}:${socket.remotePort}`);
        roClients.push(socket);

        socket.on('data', (data) => {

            buffer += data.toString('utf8').replace(/\0/g, '');  // Add new data to buffer and remove null characters
            let endTag = '</mos>';  // Define the end tag of the XML message
            let endIndex = buffer.indexOf(endTag);  // Look for the end of the message

            while (endIndex !== -1) {
                // Extract the full message (endIndex + endTag length gives the full XML)
                let fullMessage = buffer.substring(0, endIndex + endTag.length);

                // Process the complete XML message
                mosRoController.processRunningOrder(socket, fullMessage);
                
                // Remove the processed message from the buffer
                buffer = buffer.substring(endIndex + endTag.length);

                // Check if there's another complete message
                endIndex = buffer.indexOf(endTag);
            }
        });

        socket.on('error', (err) => {
            logger.error(`RO connection error: ${err.message}`);
        });

        socket.on('close', () => {
            logger.info(`RO connection closed: ${socket.remoteAddress}:${socket.remotePort}`);
            roClients = roClients.filter((client) => client !== socket);  // Remove closed connection
        });
    });

    roServer.listen(MOS_UPPER_PORT, () => {
        logger.info(`RO Service listening on port ${MOS_UPPER_PORT}`);
    });
};

/**
 * Send a message to all connected RO clients.
 */
const sendToRoClients = (message) => {
    roClients.forEach((client) => {
        client.write(message);
    });
    logger.info(`Sent message to ${roClients.length} RO clients`);
};

module.exports = {
    startRoService,
    sendToRoClients
};
