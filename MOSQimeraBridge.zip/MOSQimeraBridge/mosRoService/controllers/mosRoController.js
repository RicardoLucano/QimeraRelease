const { log } = require('winston');
const { logger } = require('../../shared/utils/logger');
const mosXmlParser = require('../../shared/utils/mosXmlParser');
const mosMessages = require('../../shared/utils/mosMessages');

const webSocketService = require('../services/wsService');

/**
 * Process incoming Running Order messages.
 * @param {string} data - The RO message received from the MOS device.
 */
async function processRunningOrder (socket, data) {
    logger.info(`Processing RO data`);
    logger.debug(`RO data: ${data}`);

    // Parse the XML message to JSON
    let mosJson = await mosXmlParser.parseXmlToJson(data);

    logger.debug(`RO JSON: ${JSON.stringify(mosJson)}`);

    // Send the parsed JSON to the WebSocket clients
    webSocketService.sendToClients(mosJson);

    // Process the JSON message
    // TODO: Add your processing logic here

    // Create a proper MOS Acknowledgement
    const mosAck = mosMessages.mosMessage_MOSAck("2016ENPS9VM001", "", "", "OK");

    // Convert the JSON Acknowledgement to XML
    let mosXmlResponse = mosXmlParser.convertJsonToXml(mosAck);

    // Send the MOS Acknowledgement to the MOS device
    logger.info(`Sending RO Acknowledgement`);
    logger.debug(`RO Acknowledgement: ${mosXmlResponse}`);
    socket.write(mosXmlParser.convertToUCS2BigEndian(mosXmlResponse));

};

module.exports = {
    processRunningOrder
};
