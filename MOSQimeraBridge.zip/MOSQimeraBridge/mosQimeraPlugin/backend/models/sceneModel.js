let scenes = [];

// Save scenes (temporary in-memory storage)
exports.saveScenes = (newScenes) => {
    scenes = newScenes;
    console.log('Scenes updated:', scenes);
};

// Retrieve stored scenes
exports.getScenes = () => {
    return scenes;
};
