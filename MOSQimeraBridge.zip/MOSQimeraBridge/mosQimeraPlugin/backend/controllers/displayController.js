const sceneModel = require('../models/sceneModel');

// Process the incoming scene data
exports.processIncomingData = (data) => {
    console.log('Processing incoming scene data...');
    sceneModel.saveScenes(data.scenes);  // Save scene data in the model
};

// Method to retrieve scenes for the API
exports.getScenes = (req, res) => {
    const scenes = sceneModel.getScenes();
    res.json({ scenes });
};
