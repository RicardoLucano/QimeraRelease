const mosPluginService = require('../services/mosPluginService');

exports.sendMosMessage = (req, res) => {
    const mosMessage = req.body.message;
    try {
        const response = mosPluginService.processMosMessage(mosMessage);
        res.json({ status: 'success', response });
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
};
