const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Serve the frontend
app.get('/qimeramosplugin.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`mosQimeraPlugin backend running on port ${PORT}`);
});
