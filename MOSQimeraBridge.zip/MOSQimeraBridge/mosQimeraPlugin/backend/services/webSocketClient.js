const WebSocket = require('ws');
const sceneController = require('../controllers/displayController');

// TODO 
// const { websocketUrl } = require('../config/config');
const websocketUrl = 'ws://localhost:8080';

let ws;

const startWebSocketClient = () => {
    ws = new WebSocket(websocketUrl);

    ws.on('open', () => {
        console.log('Connected to mainQimeraService');
    });

    ws.on('message', (message) => {
        const data = JSON.parse(message);
        console.log('Received scene data:', data);
        
        // Send the data to the controller to process it
        sceneController.processIncomingData(data);
    });

    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
    });

    ws.on('close', () => {
        console.log('WebSocket connection closed. Reconnecting...');
        setTimeout(startWebSocketClient, 5000);  // Attempt to reconnect
    });
};

module.exports = { startWebSocketClient };
