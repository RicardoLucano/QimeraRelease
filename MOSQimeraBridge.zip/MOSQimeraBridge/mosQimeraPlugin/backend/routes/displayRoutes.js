const express = require('express');
const sceneController = require('../controllers/displayController');
const router = express.Router();

// API endpoint to get the scenes
router.get('/scenes', sceneController.getScenes);

module.exports = router;
