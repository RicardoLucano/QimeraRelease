const express = require('express');
const router = express.Router();
const mosController = require('../controllers/mosController');

// POST route to send MOS messages
router.post('/sendMosMessage', mosController.sendMosMessage);

module.exports = router;
