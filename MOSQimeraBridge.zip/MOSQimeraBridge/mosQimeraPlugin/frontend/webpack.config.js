const path = require('path');
const webpack = require('webpack');

const { WEB_CLIENT_PORT } = require('../../shared/appConfig');

module.exports = {
    entry: ['core-js/stable', 'regenerator-runtime/runtime', './src/index.js'],
    target: ['web', 'es5'], // Ensure Webpack outputs ES5 code for web browsers
    output: {
        path: path.resolve(__dirname, 'dist'), // Output directory
        filename: 'bundle.js', // Output bundle file name
        publicPath: '/', // Public URL of the output directory when referenced in a browser
        environment: {
            arrowFunction: false  // Forces Webpack to avoid arrow functions in its code
        }
    },
    mode: 'production', // Set mode to production
    devServer: {
        static: {
            directory: path.join(__dirname, 'public'), // Serve static files from the public directory
        },
        historyApiFallback: true, // Redirect 404s to /index.html
        port: WEB_CLIENT_PORT, // Development server port
    },
    devtool: 'source-map', // Enable source maps for debugging
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules\/(?!(webpack)\/).*/, // Transpile even Webpack's runtime code
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            ["@babel/preset-env", {
                                targets: {
                                    ie: "11" // Target IE 11
                                },
                                useBuiltIns: "entry",
                                corejs: 3
                            }]
                        ]
                    }
                }
            },
            {
                test: /\.jsx?$/, // This handles .js and .jsx files
                exclude: /node_modules/,
                use: 'babel-loader', // Use Babel loader for JavaScript files
            },
            {
                test: /\.css$/, // This handles .css files
                use: ['style-loader', 'css-loader'], // Apply style-loader and css-loader
            },
        ],
    },
    resolve: {
        extensions: ['.js', '.jsx'], // Allow importing JS and JSX files without specifying the extension,
        fallback: {
            "stream": require.resolve("stream-browserify"),
            "timers": require.resolve("timers-browserify")
        }
    },
    plugins: [
        new webpack.ProvidePlugin({
            Buffer: ['buffer', 'Buffer']
        })
    ]
};
