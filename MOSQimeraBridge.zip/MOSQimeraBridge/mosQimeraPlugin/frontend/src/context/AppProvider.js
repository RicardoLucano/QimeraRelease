import React, { createContext, useReducer } from 'react'; 
import messageReducer from '../reducers/messageReducer';

export const AppContext = createContext();

const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(messageReducer, {});

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export default AppProvider;
