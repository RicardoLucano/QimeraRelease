
import React, { useEffect, useReducer, useContext } from 'react';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import TabNavigation from './components/Tabs/TabNavigation';
import Header from './components/Shared/Header'; // Correct import 
import InstanceSelector from './components/Shared/InstanceSelector';

import * as wsClient from './services/websocketService'; // Import the WebSocket client
import * as roWsClient from './services/roWsClient'; // Import the Read-Only WebSocket client

import { AppContext } from './context/AppProvider';

const App = () => {
    const { dispatch } = useContext(AppContext); // Get dispatch from context
    let { state } = useContext(AppContext); // Get state from context 

    //const [state, dispatch] = useReducer(messageReducer, {}); // Manage state directly

    useEffect(() => {
        wsClient.startWebSocketConnection(dispatch);
        // Initialize the WebSocket connection to receive messages from the ro server
        roWsClient.startWebSocketConnection(dispatch); // Start the Read-Only WebSocket connection
    }, [dispatch]);

    const handleSelectInstance = (instance) => {
        if (!instance) {
            console.warn('No instance selected or instance does not exist.');
            dispatch({ type: 'delete', instanceId: '', module: 'switcherData' });
            return;
        }

        console.log('Selected instance:', instance);
        // Ask the server to send data for the selected instance
        dispatch({ type: 'get', instanceId: instance.id, module: 'generalData', moduleData: { subModule: 'instanceData', data: instance.id } });

    };

    return (
        <Router>
            <div>
                <Header />
                <InstanceSelector onSelectInstance={handleSelectInstance} />
                {state.instanceData?.instanceId ? (
                    <TabNavigation />
                ) : null}
            </div>
        </Router>
    );

};

export default App;
