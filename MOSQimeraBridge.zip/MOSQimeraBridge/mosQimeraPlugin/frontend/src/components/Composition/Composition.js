import React, { useState } from 'react';

// TODO Remove template code and implement the Composition component

const Composition = () => {
    const [activeTab, setActiveTab] = useState('Qimera'); // Default active tab

    return (
        <div className="composition-container">
            <h1>Composition Component Placeholder</h1>
        </div>
    );
};

export default Composition;