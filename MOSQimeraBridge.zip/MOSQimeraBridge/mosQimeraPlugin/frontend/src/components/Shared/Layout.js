// src/components/Shared/Layout.js
import React from 'react';
import './layout.css';  // Import the styles for the layout

const Layout = ({ leftTop, leftBottom, rightContent }) => {
    return (
        <div className="layout-container">
            <div className="left-section">
                <div className="left-top">{leftTop}</div>
                <div className="left-bottom">{leftBottom}</div>
            </div>
            <div className="right-section">
                {rightContent}
            </div>
        </div>
    );
};

export default Layout;
