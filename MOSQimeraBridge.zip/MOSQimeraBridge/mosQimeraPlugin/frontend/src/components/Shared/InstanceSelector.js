import React, { useContext, useEffect, useState } from 'react';
import { AppContext } from '../../context/AppProvider';
import './InstanceSelector.css';

const InstanceSelector = ({ onSelectInstance }) => {
  const { state } = useContext(AppContext);
  const instances = state.instances || [];

  // Initial selected ID from context
  const initialId = state.instanceData?.instanceId || "";
  const [selectedId, setSelectedId] = useState(initialId);

  // Handle invalid selectedId if it no longer exists in the list
  useEffect(() => {
    const exists = instances.find(inst => inst.id === selectedId);

    if (!exists && selectedId !== "") {
      setSelectedId(""); // Reset select dropdown     
      onSelectInstance(null); // Notify parent
    }
  }, [state, instances, selectedId, onSelectInstance]);


  const handleSelectChange = (event) => {
    const newId = event.target.value;
    const instance = instances.find(inst => inst.id === newId);

    if (!state.instanceData) {
      state.instanceData = {};
    }

    console.log('Selected instance:', instance);
    state.instanceData.instanceId = newId;
    setSelectedId(newId);
    onSelectInstance(instance);
  };

  return (
    <div className="instance-selector">
      <h2>Select an Instance</h2>
      <select onChange={handleSelectChange} value={selectedId}>
        <option value="" disabled>Select an instance</option>
        {instances.length === 0 ? (
          <option value="" disabled>No instances available.</option>
        ) : (
          instances.map((instance) => (
            <option key={instance.id} value={instance.id}>
              {instance.name}
            </option>
          ))
        )}
      </select>
    </div>
  );
};

export default InstanceSelector;
