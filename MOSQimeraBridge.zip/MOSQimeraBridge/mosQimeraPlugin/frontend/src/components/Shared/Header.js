import React from 'react';
import './../../../public/styles/header.css'; // Import the styles for the header

const Header = () => {
  return (
    <header className="header">
      <img src="/images/qimeraLogo.png" alt="Logo" className="logo" /> {/* Use the correct path */}
    </header>
  );
};

export default Header;
