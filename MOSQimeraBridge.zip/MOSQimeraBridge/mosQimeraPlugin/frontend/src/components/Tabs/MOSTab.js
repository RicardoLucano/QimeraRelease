import React, { useState } from 'react';

import Composition from '../Composition/Composition';
import Switcher from '../Switcher/Switcher';
import Library from '../Library/Library';

// Component Import
import MosMenu from '../Mos/MosMenu';

import './MOSTab.css'; // Import the CSS file for styling

import * as mosMessages from '../../../../../shared/utils/mosMessages'; // Import the mosMessages utility functions
import * as mosXmlParser from '../../../../../shared/utils/mosXmlParser'; // Import the mosXmlParser utility functions

import { sendWebSocketMessage } from '../../services/websocketService'; // Import the websocket service
import { send } from 'process';

const MOSTab = () => {
    const [activeTab, setActiveTab] = useState('Composition'); // Default active tab

    const handleSendMosMessage = (mosXml) => {
        // Logic to create a MOS message
        console.log(`Sending MOS message: ${mosXml}`);
        window.parent.postMessage(mosXml, "*");
    };

    const onSwitcherData = (data) => {
        console.log('Switcher data', JSON.stringify(data));

        
        // Show a popup to confirm "ADD TO MOS".
        // TODO: Create a custom modal component for better user experience
        // For now, we will use the default window.confirm method.
        const confirmAddToMos = window.confirm("Do you want to add this data to MOS?");
        if (confirmAddToMos) {
            console.log("Adding to MOS:", data);
            
            let mosMsg = mosMessages.mosMessage_NCSItem(mosMessages.parseTriggerDataToItem(data, 'qimera.mos'));
            let mosXml = mosXmlParser.convertJsonToXml(mosMsg);

            // Set the MOS message to the state
            handleSendMosMessage(mosXml);
        }
    }

    // TODO: Add the onStoryItem function to handle the story item data
    // This function will be called when a story item is selected in the MosMenu component
    const onStoryItem = (data) => {
        const type = data?.itemType;
        const metaData = data?.mosExternalMetadata?.payload;

        if (type === 'Trigger') {
            if (metaData) {
                const instanceId = metaData?.instanceId;

                const triggerEvent =
                {
                    "type": "event",
                    "module": "switcherData",
                    "instanceId": instanceId,
                    "moduleData": {
                        "subModule": "triggerData",
                        "data": {
                            "triggerName": metaData?.triggerName,
                            "categoryID": metaData?.categoryID
                        }
                    }
                };
                sendWebSocketMessage(triggerEvent);
            }
        }

    }

    const renderActiveTab = () => {
        switch (activeTab) {
            case 'Composition':
                return <Composition />;
            case 'Switcher':
                return <Switcher onSwitcherData={onSwitcherData} />;
            case 'Library':
                return <Library />;
            default:
                return null;
        }
    };

    return (
        <div>
            <div className="mos-tab-menu">
                <MosMenu
                    onStoryItem={onStoryItem} // Pass the onStoryItem function to MosMenu
                />
            </div>

            <div className="qimera-tab-container">
                <div className="qimera-tab-list">
                    <button
                        onClick={() => setActiveTab('Composition')}
                        className={`qimera-tab-button ${activeTab === 'Composition' ? 'active' : ''}`}
                    >
                        Composition
                    </button>
                    <button
                        onClick={() => setActiveTab('Switcher')}
                        className={`qimera-tab-button ${activeTab === 'Switcher' ? 'active' : ''}`}
                    >
                        Switcher
                    </button>
                    <button
                        onClick={() => setActiveTab('Library')}
                        className={`qimera-tab-button ${activeTab === 'Library' ? 'active' : ''}`}
                    >
                        Library
                    </button>
                </div>
                <div className="qimera-tab-content">
                    {renderActiveTab()}
                </div>
            </div>


        </div>
    );
};

export default MOSTab;
