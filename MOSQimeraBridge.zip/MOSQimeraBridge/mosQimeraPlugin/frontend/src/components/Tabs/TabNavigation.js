import React, { useState } from 'react';
import './../../../public/styles/tabnavegation.css'; // Import the styles for the tabs


import QimeraTab from './QimeraTab';
import MOSTab from './MOSTab';

const TabNavigation = () => {
  const [activeTab, setActiveTab] = useState('Qimera'); // Default to Qimera Tab

  return (
    <div className="tabs-container">
      <div className="tabs">
        <button
          className={`tab-button ${activeTab === 'Qimera' ? 'active' : ''}`}
          onClick={() => setActiveTab('Qimera')}
        >
          Qimera Tab
        </button>
        <button
          className={`tab-button ${activeTab === 'MOS' ? 'active' : ''}`}
          onClick={() => setActiveTab('MOS')}
        >
          MOS Tab
        </button>
      </div>
      <div className="tab-content">
        {activeTab === 'Qimera' && <QimeraTab />}
        {activeTab === 'MOS' && <MOSTab />}
      </div>
    </div>
  );
};

export default TabNavigation;
