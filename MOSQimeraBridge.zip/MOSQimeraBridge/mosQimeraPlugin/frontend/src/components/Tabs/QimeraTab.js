// src/components/Tabs/QimeraTab/QimeraTab.js
import React, { useState } from 'react';
import Composition from '../Composition/Composition';
import Switcher from '../Switcher/Switcher';
import Library from '../Library/Library';
import './QimeraTab.css'; // Import the CSS file for styling
import { sendWebSocketMessage } from '../../services/websocketService'; // Import the websocket service


const QimeraTab = () => {
    const [activeTab, setActiveTab] = useState('Composition'); // Default active tab

    // Callback to handler the switcher data
    const onSwitcherData = (data) => {
        console.log('Switcher data', data);

        // Send the message to the server
        sendWebSocketMessage(data);
    };

    const renderActiveTab = () => {
        switch (activeTab) {
            case 'Composition':
                return <Composition />;
            case 'Switcher':
                return <Switcher onSwitcherData={onSwitcherData} />;
            case 'Library':
                return <Library />;
            default:
                return null;
        }
    };

    return (
        <div className="qimera-tab-container">
            <div className="qimera-tab-list">
                <button 
                    onClick={() => setActiveTab('Composition')} 
                    className={`qimera-tab-button ${activeTab === 'Composition' ? 'active' : ''}`}
                >
                    Composition
                </button>
                <button 
                    onClick={() => setActiveTab('Switcher')} 
                    className={`qimera-tab-button ${activeTab === 'Switcher' ? 'active' : ''}`}
                >
                    Switcher
                </button>
                <button 
                    onClick={() => setActiveTab('Library')} 
                    className={`qimera-tab-button ${activeTab === 'Library' ? 'active' : ''}`}
                >
                    Library
                </button>
            </div>
            <div className="qimera-tab-content">
                {renderActiveTab()}
            </div>
        </div>
    );
};

export default QimeraTab;
