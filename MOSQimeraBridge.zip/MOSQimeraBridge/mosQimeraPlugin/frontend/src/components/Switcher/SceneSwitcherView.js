// src/components/Switcher/SceneSwitcherView.js
import React from 'react';
import PanelGrid from './PanelGrid';  // Placeholder for panels related to the selected scene
import CategoryGrid from './CategoriesGrid';  // Placeholder for categories related to the selected scene
import './sceneSwitcherView.css';    // Import styles for this view

const SelectDefaultScene = () => {
    return (
        <div className="no-scene-selected">
            Please select a scene to view its panels.
        </div>
    );
};


const SceneSwitcherView = ({ selectedScene, onTriggerClick }) => {
    return (        
        <div className="scene-switcher-view-container">
            <div className="trigger-label">Triggers</div>
            <div className="scene-label">Scene: {selectedScene?.sceneName}</div>
            {selectedScene ? (
                <CategoryGrid scene={selectedScene} onTriggerClick={onTriggerClick} />
            ) : (
                <SelectDefaultScene />
            )}
        </div>
    );
};

export default SceneSwitcherView;
