// src/components/Switcher/Switcher.js
import React, { useState, useContext, useEffect } from 'react';
import Layout from './../Shared/Layout';
import SceneGrid from './SceneGrid';
import SceneSwitcherView from './SceneSwitcherView';
import { AppContext } from '../../context/AppProvider'; // Import the context

const Switcher = ({onSwitcherData}) => {
    const [selectedScene, setSelectedScene] = useState(null);
    
    const { state } = useContext(AppContext);
    // Access the instances from the state using optional chaining and nullish coalescing
    const scenes = state?.instanceData?.switcherData?.sceneData?.scenes ?? [];

    // Set the initial selected scene when scenes are loaded
    useEffect(() => {
        if (state?.instanceData?.activeScene?.ActiveScene) {
            const initialScene = scenes.find(scene => scene.sceneName === state.instanceData.activeScene.ActiveScene);
            setSelectedScene(initialScene || null);
        }
    }, [state?.instanceData?.activeScene?.ActiveScene]);

    // Callback to handle trigger click
    const onTriggerClick = (trigger) => {
        console.log('Trigger clicked', trigger);

        // Get instanceId from the state
        const instanceId = state?.instanceData?.instanceId;

        // Create a message to be sent to the server
        const switcherMessage = {
            type: 'event',
            module: 'switcherData',
            instanceId: instanceId,
            moduleData: {
                subModule: 'triggerData',
                data: {
                    triggerName: trigger.triggerName,
                    buttonName: trigger.buttonName,
                    panelID: trigger.panelID,
                    sceneID: trigger.sceneID,
                    categoryID: trigger.panelID
                }
            }
        };

        onSwitcherData(switcherMessage);
    };

    // Callback to handle left action on a scene
    const onLeftAction = (scene) => {
        console.log('Left action on scene:', scene);
        // Implement the left action logic here

        // setSelectedScene(scene); // Set the selected scene for further actions

        // Create a message to be sent to the server
        const switcherMessage = {
            type: 'event',
            module: 'switcherData',
            instanceId: state?.instanceData?.instanceId,
            moduleData: {
                subModule: 'sceneData',
                data: {
                    sceneName: scene.sceneName,
                    action: 'leftAction'
                }
            }
        };

        // Send the message to the server
        onSwitcherData(switcherMessage);
    };

    // Callback to handle right action on a scene
    const onRightAction = (scene) => {
        console.log('Right action on scene:', scene);
        // Implement the right action logic here

        // Only set selected scene if it's different from current
        setSelectedScene(scene); // Set the selected scene for further actions      
    };

    return (
        <Layout
            leftTop={<div>Preview (for future)</div>}
            leftBottom={
                <SceneGrid
                    scenes={scenes} // Pass the scenes to the grid
                    onLeftAction={onLeftAction}
                    onRightAction={onRightAction}
                />
            }
            rightContent={
                <SceneSwitcherView selectedScene={selectedScene} onTriggerClick={onTriggerClick} />
            }
        />
    );
};

export default Switcher;