// src/components/Switcher/Trigger.js
import React from 'react';
import './trigger.css'; // Import individual styles for each trigger

const Trigger = ({ trigger, onTriggerClick }) => {
  // Normalize background color to #RRGGBBAA format
  const backgroundColor = trigger.color?.startsWith('#')
    ? trigger.color
    : '#' + trigger.color;

  // Foreground color is black or white depending on brightness
  const foregroundColor =
    parseInt(backgroundColor.substr(1, 6), 16) > 0xffffff / 2
      ? 'black'
      : 'white';

  // Extra classes for status
  const classes = [
    'trigger',
    trigger.status?.pageIndex ? 'page-index' : '',
    trigger.status?.activeness ? 'activeness' : ''
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <button
      className={classes}
      style={{ backgroundColor, color: foregroundColor }}
      onClick={() => onTriggerClick(trigger)}
    >
      {trigger.buttonName}
    </button>
  );
};

export default Trigger;
