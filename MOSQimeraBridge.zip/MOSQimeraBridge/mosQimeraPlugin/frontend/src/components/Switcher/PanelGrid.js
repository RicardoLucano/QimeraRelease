// src/components/Switcher/PanelGrid.js
import React, { useState, useContext } from 'react';
import TriggerGrid from './TriggerGrid'; // Import TriggerGrid component
import './panelGrid.css';

import { AppContext } from '../../context/AppProvider'; // Import the context

const PanelGrid = ({ scene, onTriggerClick }) => {
    const { state } = useContext(AppContext);

    // Access the panels and filter for the current scene
    const panels = state?.panelData?.panels?.filter(panel => panel.sceneID === scene.sceneName) ?? [];

    
    return (
        <div className="panel-grid-container">
            {panels.map((panel) => (
                <div key={panel.panelName} className="panel">
                    <div className="panel-name">{panel.panelName}</div>
                    <TriggerGrid sceneID={scene.sceneName} panelID={panel.panelName} onTriggerClick={onTriggerClick} />
                </div>
            ))}
        </div>
    );
};

export default PanelGrid;
