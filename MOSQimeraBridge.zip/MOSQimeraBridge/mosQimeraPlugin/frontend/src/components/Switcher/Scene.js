// src/components/Switcher/Scene.js
import React, { useContext } from 'react';
import './scene.css';
import { AppContext } from '../../context/AppProvider';

const Scene = ({ scene, onLeftAction, onRightAction, yellowSceneName, currentSceneName }) => {
    const { state } = useContext(AppContext);

    const thumbnails = state?.instanceData?.switcherData?.sceneThumbnails?.scenes || [];
    const currentThumbnail = thumbnails.find(thumbnail => thumbnail.sceneName === scene.sceneName);
    let base64Thumbnail = currentThumbnail?.imageBase64 || 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR42mP8//8/AwAI/wH+9Q4AAAAASUVORK5CYII=';

    const isCurrentScene = currentSceneName === scene.sceneName;
    const isYellow = yellowSceneName === scene.sceneName;

    let itemClass = 'scene-item';
    if (isCurrentScene) {
        itemClass += ' scene-red';
    } else if (isYellow) {
        itemClass += ' scene-yellow';
    }

    return (
        <div className={itemClass}>
            <div className="scene-title">{scene.sceneName}</div>
            <div className="scene-preview">
                <img
                    className="scene-thumbnail"
                    src={base64Thumbnail}
                    alt={scene.sceneName}
                />
                <div className="scene-overlay">
                    <div
                        className="scene-half left-half"
                        onClick={() => onLeftAction(scene)}
                    />
                    <div
                        className="scene-half right-half"
                        onClick={() => onRightAction(scene)}
                    />
                </div>
            </div>
        </div>
    );
};

export default Scene;
