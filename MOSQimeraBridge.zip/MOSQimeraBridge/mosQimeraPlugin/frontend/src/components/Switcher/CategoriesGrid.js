// src/components/Switcher/PanelGrid.js
import React, { useState, useContext } from 'react';
import TriggerGrid from './TriggerGrid'; // Import TriggerGrid component
import './categoryGrid.css';

import { AppContext } from '../../context/AppProvider'; // Import the context

const CategoriesGrid = ({ scene, onTriggerClick }) => {
    const { state } = useContext(AppContext);

    // Access the categories and filter for the current scene
    //const panels = state?.panelData?.panels?.filter(panel => panel.sceneID === scene.sceneName) ?? [];
    const categories = state?.instanceData?.switcherData?.categoriesData?.categories ?? [];

    // Check if the categories are in the displayed list fo the scene
    const displayedCategories = scene?.DisplayedCategories || [];    
    const filteredCategories = categories.filter(category => displayedCategories.includes(category.categoryName));
    
    return (
        <div className="category-grid-container">
            {filteredCategories.map((category) => (
                <div key={category.categoryName} className="category">
                    <div className="category-name">{category.categoryName}</div>
                    <TriggerGrid sceneID={scene.sceneName} panelID={category.categoryName} onTriggerClick={onTriggerClick} />
                </div>
            ))}
        </div>
    );
};

export default CategoriesGrid;
