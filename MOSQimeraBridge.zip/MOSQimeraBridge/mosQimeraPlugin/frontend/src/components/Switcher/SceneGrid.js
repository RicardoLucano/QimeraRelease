// src/components/Switcher/SceneGrid.js
import React, { useState, useContext, useEffect } from 'react';
import Scene from './Scene';
import './sceneGrid.css';

import { AppContext } from '../../context/AppProvider'; // Assuming context holds currentSceneName

const SceneGrid = ({ scenes, onLeftAction, onRightAction }) => {
    const { state } = useContext(AppContext);
    const currentSceneName = state?.instanceData?.activeScene?.ActiveScene || null;
    const [yellowSceneName, setYellowSceneName] = useState(null);

    // ✅ Reset yellow highlight when current scene changes (from a message)
    useEffect(() => {
        setYellowSceneName(null);
    }, [currentSceneName]);

    // ✅ Central right-click handler
    const handleRightClick = (scene) => {
        if (scene.sceneName !== currentSceneName) {
            setYellowSceneName(scene.sceneName);
        } else {
            setYellowSceneName(null);
        }
        onRightAction(scene);
    };

    return (
        <div className="scene-grid-container">
            {scenes.map(scene => (
                <div key={scene.sceneName} className="scene-wrapper">
                    <Scene
                        scene={scene}
                        onLeftAction={onLeftAction}
                        onRightAction={handleRightClick}
                        yellowSceneName={yellowSceneName}
                        currentSceneName={currentSceneName}
                    />
                </div>
            ))}
        </div>
    );
};

export default SceneGrid;
