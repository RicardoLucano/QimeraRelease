// src/components/Switcher/TriggerGrid.js
import React, { useContext } from 'react';
import Trigger from './Trigger';
import './triggerGrid.css';
import { AppContext } from '../../context/AppProvider';

const TriggerGrid = ({ sceneID, panelID, onTriggerClick }) => {
  const { state } = useContext(AppContext);

  const allTriggers = state?.instanceData?.switcherData?.triggerData?.triggers ?? [];
  const triggerStatus = state?.instanceData?.switcherData?.triggerStatus ?? {};

  // Merge trigger data with their current statuses
  const triggers = allTriggers
    .filter(trigger => trigger.panelID === panelID)
    .map(trigger => ({
      ...trigger,
      status: triggerStatus[trigger.triggerName] || {}
    }));

  return (
    <div className="trigger-grid">
      {triggers.map(trigger => (
        <Trigger
          key={trigger.triggerName}
          trigger={trigger}
          onTriggerClick={onTriggerClick}
        />
      ))}
    </div>
  );
};

export default TriggerGrid;
