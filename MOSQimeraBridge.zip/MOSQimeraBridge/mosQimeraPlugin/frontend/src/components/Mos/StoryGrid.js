import React from "react";

import StoryView from "./StoryView";

import './storyGrid.css';  // Import styles for this view

const StoryGrid = ({ stories, OnRunStoryItem }) => {
    console.log('StoryGrid', stories);
    // Assuming stories is an array of story objects

    const OnRunItem = (item) => {
        OnRunStoryItem(item); // Call the parent function with the item data
    }

    return (
        <div className="story-grid">
            {stories.map((story, index) => (
                <div key={index} className="story-item">
                    <StoryView story={story} OnRunItem={OnRunItem}/>
                </div>
            ))}
        </div>
    );
}

export default StoryGrid;