// MosMenu.js

// React Imports
import React, { useContext } from 'react';


// Style Import
//import './MOSTab.css';
// TODO: Add styles for the MosMenu in a file named MosMenu.css
// import './MosMenu.css'; // Uncomment this line when you create the CSS file
import { AppContext } from '../../context/AppProvider'; // Import the context
import StoryGrid from './StoryGrid';

import './mosMenu.css'; // Import the CSS file for styling

// MosMenu Component
const MosMenu = ({ handleSendMosMessage, onStoryItem}) => {

    // Function to handle sending the MOS message

    const { state } = useContext(AppContext);
    const allStories = state?.stories ?? [];

    const OnRunStoryItem = (item) => {
        console.log("Running item:", item);
        onStoryItem(item); // Call the parent function with the item data
    };

    return (
        <div className="mos-tab-container">
            <h2 className="mos-tab-title">MOS Section</h2>            
            <div className="mos-story-grid">
                <h3 className="mos-story-grid-title">Stories</h3>
                <StoryGrid stories={allStories} OnRunStoryItem={OnRunStoryItem} />
            </div>

        </div>
    );
};

export default MosMenu;
