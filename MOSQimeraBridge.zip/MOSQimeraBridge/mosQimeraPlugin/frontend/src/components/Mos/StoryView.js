import React, { useState } from "react";
import "./storyView.css"; // Import the CSS file for styling

const StoryView = ({ story, OnRunItem }) => {
  const [expanded, setExpanded] = useState(false);
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [lastPlayedIndex, setLastPlayedIndex] = useState(null); // Track only last played

  if (!story) {
    return <div>No story selected</div>;
  }

  let storyItems = story?.storyBody?.storyItem ?? [];
  if (!Array.isArray(storyItems)) {
    storyItems = [storyItems];
  }


  // if (storyItems.length === 0) {
  //  return <div>No items in this story</div>;
  // }

  const handleExpand = () => {
    setExpanded(!expanded);
  };

  const handleNext = () => {
    const currentItem = storyItems[currentItemIndex];
    OnRunItem(currentItem);

    // Update last played index before changing current
    setLastPlayedIndex(currentItemIndex);

    if (currentItemIndex < storyItems.length - 1) {
      setCurrentItemIndex(currentItemIndex + 1);
    } else {
      setCurrentItemIndex(0);
      setLastPlayedIndex(null); // Reset on loop
    }
  };

  return (
    <div className={`story-view ${expanded ? "expanded" : ""}`}>
      <div className="story-header">
        <button className="expand-button" onClick={handleExpand}>
          <img
            src={
              expanded ? "/icons/collapse-icon.svg" : "/icons/expand-icon.svg"
            }
            className="expand-icon"
          />
        </button>
        <h3 className="story-title">{story.storySlug}</h3>
      </div>
      {expanded && (
        <div className="story-items-grid">
          {storyItems.map((item, index) => {
            let itemClass = "story-item";
            if (index === currentItemIndex) itemClass += " current";
            else if (index === lastPlayedIndex) itemClass += " played";

            return (
              <div key={index} className={itemClass}>
                <h4>{item.itemSlug}</h4>
              </div>
            );
          })}
          <button className="go-next-button" onClick={handleNext}>
            Go Next
          </button>
        </div>
      )}
    </div>
  );
};

export default StoryView;
