// index.js
import 'babel-polyfill';
import 'core-js/stable';
import 'regenerator-runtime/runtime';
import React from 'react';
import ReactDOM from 'react-dom/client'; // Use createRoot from React 18
import App from './App';
import AppProvider from './context/AppProvider'; // Make sure the path is correct

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
    <AppProvider>
      <App />
    </AppProvider>
);
