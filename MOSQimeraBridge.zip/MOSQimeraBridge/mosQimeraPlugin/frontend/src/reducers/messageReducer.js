import moduleHandlers from '../handlers/moduleHandlers';

const messageReducer = (state, action) => {
  const moduleHandler = moduleHandlers[action.module];
  console.log(`Handling action: ${action.module}`);
  if (moduleHandler) {
    return moduleHandler(state, action);
  }

  console.warn(`Unhandled action: ${action.module}`);
  return state;
};

export default messageReducer;
