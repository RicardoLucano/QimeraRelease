// Require appConfig.js to get the server URL and port
// const { WS_MAIN_SERVER_URL, WS_MAIN_SERVER_PORT } = require('./../../../../shared/appConfig');
import config from './../../../../config.json';

console.log('Config loaded:', config);
const WS_MAIN_SERVER_URL = config.wsMain.url;
const WS_MAIN_SERVER_PORT = config.wsMain.port;


const url = WS_MAIN_SERVER_URL;
const port = WS_MAIN_SERVER_PORT; // Replace with your server port

const completeUrl = `${url}:${port}`;
console.log('WebSocket URL:', completeUrl);

const ws = new WebSocket(completeUrl);

const startWebSocketConnection = (dispatch) => {
  ws.onopen = () => {
    console.log('WebSocket connection established');
  };

  ws.onmessage = (message) => {
    const parsedMessage = JSON.parse(message.data);
    console.log('Received message:', parsedMessage);
    dispatch(parsedMessage);
  };

  ws.onclose = () => {
    console.log('WebSocket connection closed');
  };

  ws.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
};

const sendWebSocketMessage = (message) => {
  console.log('Sending message:', message);
  ws.send(JSON.stringify(message));
};

export {
  startWebSocketConnection,
  sendWebSocketMessage
};
