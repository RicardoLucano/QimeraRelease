import config from './../../../../config.json';

console.log('Config loaded:', config);
const WS_MAIN_SERVER_URL = config.wsRo.url;
const WS_MAIN_SERVER_PORT = config.wsRo.port;


const url = WS_MAIN_SERVER_URL;
const port = WS_MAIN_SERVER_PORT; // Replace with your server port

const completeUrl = `${url}:${port}`;
console.log('WebSocket URL:', completeUrl);

const ws = new WebSocket(completeUrl);

const startWebSocketConnection = (dispatch) => {
  ws.onopen = () => {
    console.log('WebSocket connection established');
  };

  ws.onmessage = (message) => {
    const parsedMessage = JSON.parse(message.data);

    // Add message headers to the parsed message
    const newMessage = {
      type: 'set',
      instanceId: '',
      module: 'roMos',
      moduleData: parsedMessage
    }; 

    dispatch(newMessage);
  };

  ws.onclose = () => {
    console.log('WebSocket connection closed');
  };

  ws.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
};

const sendWebSocketMessage = (message) => {
  console.log('Sending message:', message);
  ws.send(JSON.stringify(message));
};

export {
  startWebSocketConnection,
  sendWebSocketMessage
};
export default ws;