export default function triggerUpdateHandler(state, action) {
  const update = action.moduleData.data; 
  const { triggerName, type } = update;

  // Map event "type" to a field in the trigger status
  const typeMapping = {
    PageIndex: { pageIndex: update.PageIndex },
    Activeness: { activeness: update.Activeness }
  };

  if (!typeMapping[type]) {
    console.warn(`Unknown trigger update type: ${type}`);
    return state;
  }

  const currentStatus =
    state.instanceData?.switcherData?.triggerStatus?.[triggerName] || {};

  return {
    ...state,
    instanceData: {
      ...state.instanceData,
      switcherData: {
        ...state.instanceData.switcherData,
        triggerStatus: {
          ...(state.instanceData.switcherData.triggerStatus || {}),
          [triggerName]: {
            ...currentStatus,
            ...typeMapping[type] // merge only the relevant status field
          }
        }
      }
    }
  };
}
