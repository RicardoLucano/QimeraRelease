const sceneDataHandler = (state, action) => {
    console.log('sceneDataHandler');
    const { moduleData, type } = action;
    switch (type) {
      case 'set':
        return { ...state, instanceData: {...state.instanceData, switcherData: { ...state.instanceData.switcherData, sceneData: moduleData.data } } };
      case 'update':
        return { ...state, instanceData: {...state.instanceData, switcherData: { ...state.instanceData.switcherData,sceneData: { ...state.instanceData.switcherData.sceneData, ...moduleData.data } } } };
      case 'delete':
        return { ...state, instanceData: {...state.instanceData, switcherData: { ...state.instanceData.switcherData, sceneData: {} } } };
      default:
        console.warn(`Unhandled action type: ${type}`);
        return state;
    }
  };
  
  export default sceneDataHandler;
  