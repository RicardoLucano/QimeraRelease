const panelDataHandler = (state, action) => {
    console.log('panelDataHandler');
    const { moduleData, type } = action;
    switch (type) {
      case 'set':
        return { ...state, panelData: moduleData.data };
      case 'update':
        return { ...state, panelData: { ...state.panelData, ...moduleData.data } };
      case 'delete':
        return { ...state, panelData: {} };
      default:
        console.warn(`Unhandled action type: ${type}`);
        return state;
    }
  };
  
  export default panelDataHandler;
  