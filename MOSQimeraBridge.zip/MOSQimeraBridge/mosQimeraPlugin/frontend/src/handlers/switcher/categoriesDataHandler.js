const panelDataHandler = (state, action) => {
    console.log('categoriesDataHandler');
    const { moduleData, type } = action;
    switch (type) {
      case 'set':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, categoriesData: moduleData.data } } };
      case 'update':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, categoriesData: { ...state.instanceData.switcherData.categoriesData, ...moduleData.data } } } };
      case 'delete':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, categoriesData: {} } } };
      default:
        console.warn(`Unhandled action type: ${type}`);
        return state;
    }
  };
  
  export default panelDataHandler;
  