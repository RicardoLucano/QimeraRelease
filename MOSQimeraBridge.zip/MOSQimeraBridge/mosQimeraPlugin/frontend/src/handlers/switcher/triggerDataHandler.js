const triggerDataHandler = (state, action) => {
    console.log('triggerDataHandler');

    const { moduleData, type } = action;
    switch (type) {
      case 'set':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, triggerData: moduleData.data } } };
      case 'update':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, triggerData: { ...state.instanceData.switcherData.triggerData, ...moduleData.data } } } };
      case 'delete':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, triggerData: {} } } };
      default:
        console.warn(`Unhandled action type: ${type}`);
        return state;
    }
  };
  
  export default triggerDataHandler;
  