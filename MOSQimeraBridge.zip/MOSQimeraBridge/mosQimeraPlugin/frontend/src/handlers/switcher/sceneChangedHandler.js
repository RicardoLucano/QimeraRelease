const sceneChangedHandler = (state, action) => {
    console.log('sceneChangedHandler');
    const { moduleData, type } = action;
    switch (type) {
      case 'set':
        return { ...state, instanceData: { ...state.instanceData, activeScene: moduleData.data } };
      case 'update':
        return { ...state, instanceData: { ...state.instanceData, activeScene: { ...state.instanceData.activeScene, ...moduleData.data } } };
      case 'delete':
        return { ...state, instanceData: { ...state.instanceData, activeScene: {} } };
      default:
        console.warn(`Unhandled action type: ${type}`);
        return state;
    }
  };
  
  export default sceneChangedHandler;
  