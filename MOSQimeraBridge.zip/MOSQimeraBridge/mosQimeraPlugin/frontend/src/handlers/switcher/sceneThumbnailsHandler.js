const sceneThumbnailsHandler = (state, action) => {
    console.log('sceneThumbnailsHandler');
    const { moduleData, type } = action;
    switch (type) {
      case 'set':
        return { ...state, instanceData : { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, sceneThumbnails: moduleData.data } } };
      case 'update':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, sceneThumbnails: { ...state.instanceData.switcherData.sceneThumbnails, ...moduleData.data } } } };
      case 'delete':
        return { ...state, instanceData: { ...state.instanceData, switcherData: { ...state.instanceData.switcherData, sceneThumbnails: {} } } };
      default:
        console.warn(`Unhandled action type: ${type}`);
        return state;
    }
  };
  
  export default sceneThumbnailsHandler;
  