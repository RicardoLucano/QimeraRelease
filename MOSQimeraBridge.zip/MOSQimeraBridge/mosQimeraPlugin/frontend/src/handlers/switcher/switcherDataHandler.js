import sceneDataHandler from './sceneDataHandler';
import panelDataHandler from './panelDataHandler';
import triggerDataHandler from './triggerDataHandler';
import triggerUpdateHandler from './triggerUpdateHandler';
import categoriesDataHandler from './categoriesDataHandler';
import sceneThumbnailsHandler from './sceneThumbnailsHandler';
import sceneChangedHandler from './sceneChangedHandler';  // Assuming this is the same as sceneDataHandler

const subHandlers = {
  sceneData: sceneDataHandler,
  sceneThumbnails: sceneThumbnailsHandler,
  currentScene: sceneChangedHandler,  // Assuming this is the same as sceneDataHandler
  panelData: panelDataHandler,
  triggerData: triggerDataHandler,
  triggerUpdate: triggerUpdateHandler, // 
  categoriesData: categoriesDataHandler,  
};

const switcherHandler = (state, action) => {
  console.log('switcherHandler');

  const { moduleData, type } = action;
  switch (type) {
    case 'delete':
      console.log('Deleting switcher data:', moduleData);
      return { ...state, instanceData: {} };
    default:
      console.log('Handling switcher data:', moduleData);
  }

  const subHandler = subHandlers[moduleData.subModule];  // Get the appropriate handler for the type

  if (subHandler) {
    return subHandler(state, action);  // Call the specific sub-handler
  }

  console.warn(`Unhandled switcher data type: ${moduleData.type}`);
  return state;  // Return unchanged state if type is not handled
};

export default switcherHandler;
