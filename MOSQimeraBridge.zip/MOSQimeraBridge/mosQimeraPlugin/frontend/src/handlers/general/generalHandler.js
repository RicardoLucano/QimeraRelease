import allInstanceHandler from './allInstanceHandler';
import instanceDataHandler from './instanceDataHandler';

const subHandlers =
{
  allInstances: allInstanceHandler,
  instanceData: instanceDataHandler,
};

const generalHandler = (state, action) =>
{
  const { moduleData, type } = action;
  const subHandler = subHandlers[moduleData.subModule];  // Get the appropriate handler for the type

  if (subHandler)
  {
    return subHandler(state, action);  // Call the specific sub-handler
  }

  console.warn(`Unhandled general data type: ${moduleData.subModule}`);
  return state;  // Return unchanged state if type is not handled
};

export default generalHandler;