
const allInstanceHandler = (state, action) => {
  const { moduleData, type } = action;
  switch (type) {
    case 'set':
      return { ...state, instances: moduleData.data };
    default:
      console.warn(`Unhandled action type: ${type}`);
      return state;
  }
};

export default allInstanceHandler;