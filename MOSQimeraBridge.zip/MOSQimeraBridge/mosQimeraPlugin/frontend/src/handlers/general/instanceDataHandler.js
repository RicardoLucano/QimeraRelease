import {sendWebSocketMessage} from './../../services/websocketService';

const instanceDataHandler = (state, action) =>
{
  const { moduleData, type } = action;
  switch (type)
  {
    // Types from the server
    case 'set':
      return { ...state, instanceData: { ...state.instanceData, generalData: { ...state.instanceData.generalData, ...moduleData.data } } };
       
    case 'update':
        return { ...state, instanceData: { ...state.instanceData, generalData: { ...state.instanceData.generalData, ...moduleData.data } } };
    case 'delete':
        return { ...state, instanceData: { ...state.instanceData, generalData: null } }; // Clear instance data on delete

    // Types from the client
    case 'get':
        // Ask the server to send data for the selected instance
        sendWebSocketMessage(action);


      return state;

    default:
      console.warn(`Unhandled action type: ${type}`);
      return state;
  }
};

export default instanceDataHandler;