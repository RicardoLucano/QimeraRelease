const libraryDataHandler = {
    set: (state, moduleData) => {
      return {
        ...state,
        libraryData: {
          ...state.libraryData,
          [moduleData.type]: moduleData.data
        }
      };
    },
  
    update: (state, moduleData) => {
      return {
        ...state,
        libraryData: {
          ...state.libraryData,
          [moduleData.type]: {
            ...state.libraryData[moduleData.type],
            ...moduleData.data
          }
        }
      };
    },
  
    delete: (state, moduleData) => {
      const { [moduleData.type]: deleted, ...rest } = state.libraryData;
      return {
        ...state,
        libraryData: rest
      };
    }
  };
  
  export default libraryDataHandler;
  