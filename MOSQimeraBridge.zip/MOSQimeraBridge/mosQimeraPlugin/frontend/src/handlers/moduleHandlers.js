import generalHandler from './general/generalHandler';
import switcherDataHandler from './switcher/switcherDataHandler';
import libraryDataHandler from './library/libraryDataHandler';
// Import other module handlers here

import roMosHandler from './mos/roMosHandler'; // Import the roMos handler


const moduleHandlers = {
  switcherData: switcherDataHandler,
  libraryData: libraryDataHandler,
  // Add more modules as needed
  generalData: generalHandler,
  roMos: roMosHandler, // Add the roMos handler here
};

export default moduleHandlers;
