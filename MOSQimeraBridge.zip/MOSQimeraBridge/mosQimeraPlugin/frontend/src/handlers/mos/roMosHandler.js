
function handleRoElementStat(state, data) {
    return state;  // Return unchanged state for now
}

function handleRoStorySend(state, data) {
    console.log("Handling roStorySend:", data);

    // Update the state with the new story data in a list of stories
    
    const storyData = data;

    // Get stories from the state
    const stories = state.stories || [];

    // Check if the story already exists in the state
    const existingStoryIndex = stories.findIndex(story => story.storyID === storyData.storyID);

    // Add or update the story in the state
    let updatedStories;
    if (existingStoryIndex !== -1) {
        // Update existing story
        updatedStories = [...stories];
        updatedStories[existingStoryIndex] = { ...updatedStories[existingStoryIndex], ...storyData };
    }
    else {
        // Add new story
        updatedStories = [...stories, storyData];
    }

    return {
        ...state,
        stories: updatedStories,  // Update the state with the new list of stories
    };
}

function handleUnknown(data) {
    console.log("Unknown event type:", data);
}

const handlers = {
    roElementStat: handleRoElementStat,
    roStorySend: handleRoStorySend,
};

//////////////////////////////
// This function handles incoming data from the WebSocket connection

function handleIncomingData(state, jsonData) {
    try {
        const parsedData = typeof jsonData === "string" ? JSON.parse(jsonData) : jsonData;
        
        // Check if the mosID field is present in the parsed data and is not empty
        if (!parsedData.mosID) {
            console.warn("mosID is missing or empty in the incoming data:", parsedData);
            return state;  // Return unchanged state if mosID is missing
        }

        // TODO: Add settings for mosID, use "MOSQIMERA" for now
        // Check if the mosID is the assigned one
        if (parsedData.mosID !== "MOSQIMERA") {
            console.warn("mosID does not match the assigned one:", parsedData.mosID);
            return state;  // Return unchanged state if mosID does not match
        }

        // Find the first key that matches a handler
        const key = Object.keys(parsedData).find(k => handlers[k]);
        
        const handler = handlers[key];
        if (!handler) {
            console.warn(`No handler found for key: ${key}`);
            return state;  // Return unchanged state if no handler is found
        }
        state = handler(state, parsedData[key]);  // Call the appropriate handler with the data

    } catch (error) {
        console.error("Error parsing JSON:", error);
        return state;  // Return unchanged state if parsing fails
    }
     
    console.log("new state:", state);
    return state;  // Return unchanged state if no handler is found
}

const roMosHandler = (state, action) => {
    console.log('roMosHandler');
    const { moduleData, type } = action;

    console.log('roMosHandler', moduleData, type);

    return handleIncomingData(state, moduleData.mos);
  };
  
export default roMosHandler;
  