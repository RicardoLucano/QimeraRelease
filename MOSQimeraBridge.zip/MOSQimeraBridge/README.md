# QIMERA WEB SERVICES

## 🔧 Setup (Windows)

1. Download and install [Node.js](https://nodejs.org/)
2. Double-click the `setup.bat` file to install prerequisites.
3. Run: `StartServices.bat` file to start the services.
