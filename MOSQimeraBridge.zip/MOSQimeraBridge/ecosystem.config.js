module.exports = {
  apps: [
    {
      name: 'mainQimeraService',
      script: 'npm',
      args: 'run start:mainQimeraService'
    },
    {
      name: 'webClient',
      script: 'npm',
      args: 'run start:webClient'
    },
    {
      name: 'ro',
      script: 'npm',
      args: 'run start:ro'
    }
  ]
}
