const net = require('net');
const mosMomController = require('../controllers/mosMomController');
const { logger } = require('../../shared/utils/logger');
const { MOS_LOWER_PORT, MOS_IP } = require('../../shared/appConfig');

const mosXmlParser = require('./../../shared/utils/mosXmlParser');

let momClients = [];  // Track clients connected to the Lower Port

/**
 * Start the MOS Lower Port (10540) server for MOM messages.
 */
const startMomService = () => {


    const momSocket = net.createConnection({ host: MOS_IP, port: MOS_LOWER_PORT }, () => {
        logger.info(`Connected to MOS (MOM) on Lower Port at ${MOS_IP}:${MOS_LOWER_PORT}`);
        momClients.push(momSocket);
    });

    momSocket.on('data', (data) => {
        mosMomController.processMetadata(data.toString());  // Process MOM data
    });

    momSocket.on('error', (err) => {
        logger.error(`MOM connection error: ${err.message}`);
    });

    momSocket.on('close', () => {
        logger.info('MOM connection closed');
        
        // Force close the socket and remove from clients list
        momSocket.destroy();
        momClients = momClients.filter((client) => client !== momSocket);  // Remove closed connection

        // Reconnect to MOS Lower Port
        setTimeout(() => {
            startMomService();
        }, 60000);
    });    
};

/**
 * Broadcast a message to all MOM clients.
 */
const broadcastToMomClients = (message) => {
    momClients.forEach((client) => {
        let ret = client.write(mosXmlParser.convertToUCS2BigEndian(message));
        if (!ret) {
            logger.error(`Failed to send message to MOM client ${client.remoteAddress}:${client.remotePort}`);
        }
    });
    logger.info(`Broadcasted message to ${momClients.length} MOM clients`);
};

module.exports = {
    startMomService,
    broadcastToMomClients
};
