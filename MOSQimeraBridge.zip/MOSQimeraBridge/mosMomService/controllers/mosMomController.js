const { logger } = require('../../shared/utils/logger');

/**
 * Process incoming Media Object Metadata messages.
 * @param {string} data - The MOM message received from the MOS device.
 */
const processMetadata = (data) => {
    logger.info(`Processing MOM data: ${data}`);
    // Add your business logic for MOM messages here
};

module.exports = {
    processMetadata
};
