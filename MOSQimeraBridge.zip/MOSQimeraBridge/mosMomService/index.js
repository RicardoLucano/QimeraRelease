// Description: Main entry point for the MOS mom service application.
const mosMomService  = require('./services/mosMomService');
const { logger } = require('./../shared/utils/logger');


// Start the MOS RO Service
mosMomService.startMomService();

const express = require('express');

const app = express();
// Middleware
app.use(express.json());


const cors = require('cors'); // Import the CORS package
app.use(cors()); // Use CORS middleware

// Add CORS headers manually if needed
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*"); // Allow all origins
    res.header("Access-Control-Allow-Methods", "GET,POST,OPTIONS"); // Allow specific methods
    res.header("Access-Control-Allow-Headers", "Content-Type"); // Allow specific headers
    next();
  });

app.use('/api/mos/', (req, res) => {
    const {message} = req.body;

    // Process the message
    logger.info(`Received message: ${message}`);
    mosMomService.broadcastToMomClients(message);

    const response = {
        message: 'Message sent to all clients'
    }
    // Send the response
    res.json({ response });
});

// Start the server
const PORT = process.env.PORT || 4001;
app.listen(PORT, () => {
    logger.info(`MOS MOM Service is running on port ${PORT}`);
});

