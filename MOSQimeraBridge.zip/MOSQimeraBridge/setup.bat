@echo off
setlocal EnableDelayedExpansion

echo [INFO] Checking if WSL is installed...
wsl --list --verbose >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] WSL is not installed. Installing WSL...
    wsl --install
    if !errorlevel! neq 0 (
        echo [ERROR] Failed to install WSL.
        pause
        exit /b !errorlevel!
    )
    echo [INFO] WSL installed successfully.
) else (
    echo [INFO] WSL is already installed.
)

:: Enable WSL feature
echo [INFO] Ensuring WSL feature is enabled...
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all >nul 2>&1

:: Set Ubuntu to WSL1 (safe if already set)
echo [INFO] Setting Ubuntu to WSL version 1...
wsl --set-version Ubuntu 1 >nul 2>&1

:: Update Ubuntu
echo [INFO] Updating Ubuntu environment...
wsl -d Ubuntu -- bash -c "sudo apt update -y && echo Ubuntu environment updated."
if !errorlevel! neq 0 (
    echo [ERROR] Failed to update Ubuntu environment.
    exit /b !errorlevel!
)

:: Install Node.js and common tools
echo [INFO] Installing Node.js, PM2, and common dev tools (webpack, ws)...
wsl -d Ubuntu -- bash -c "sudo apt update -y && sudo apt install -y curl && curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash - && sudo apt install -y nodejs && sudo npm install -g pm2 ws webpack webpack-cli webpack-dev-server xml2js xmlbuilder"
if !errorlevel! neq 0 (
    echo [ERROR] Failed to install Node.js or tools.
    exit /b !errorlevel!
)

:: npm audit fix --force
wsl -d Ubuntu -- bash -c "npm audit fix --force"


:: Configure PM2 to start on boot
echo [INFO] Configuring PM2 to auto-start...
wsl -d Ubuntu -- bash -c "pm2 startup systemd -u $(whoami) --hp $HOME"

wsl -d Ubuntu pm2 save
echo [SUCCESS] Node.js, PM2, and tools installed. PM2 auto-start is configured.

pause
endlocal
