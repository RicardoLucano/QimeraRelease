
const xml2js = require('xml2js');
const xmlbuilder = require('xmlbuilder');

// XML parser
const parser = new xml2js.Parser({ explicitArray: false });

/**
 * Converts a string to UCS-2 (Big Endian)
 * @param {string} str - The string to convert
 * @returns {Buffer} The converted string
 */
const convertToUCS2BigEndian = (str) => {
    const buffer = Buffer.alloc(str.length * 2);
    for (let i = 0; i < str.length; i++) {
      buffer.writeUInt16BE(str.charCodeAt(i), i * 2); // Big Endian
    }
    return buffer;
}

/**
 * Parse an XML string to a JSON object. Asynchronous.
 * @param {string} xml - The XML string to parse
 * @returns {Promise} A promise that resolves to the JSON object
 */
const parseXmlToJson = (xml) => {
    return new Promise((resolve, reject) => {
        parser.parseString(xml, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
}

/**
 * Convert a JSON object to an XML string.
 * headless: true removes the declaration
 * pretty: true adds newlines and indentation
 * allowEmpty: true allows empty elements
 * 
 * @param {object} json - The JSON object to convert
 * @returns {string} The XML string
 */
const convertJsonToXml = (json) => {
    try {
        return xmlbuilder.create(json, { headless: true })
            .end({ pretty: true, allowEmpty: true });
    }
    catch (err) {
        console.error(err);
        return '';
    }
}            


module.exports = {
    convertToUCS2BigEndian,
    parseXmlToJson,
    convertJsonToXml
};