//  File: mosMessages.js
//  Description: This file contains the mos messages that are used in the MOS protocol.

function createMessageId() {
    return Math.random().toString(36).substr(2, 9);
}

// Basic Object Communication

/**
 * Create a new mos message object.
 * @param {string} mosID - The mosID of the sender.
 * @param {string} ncsID - The ncsID of the sender.
 * @param {Object} messageContent - The content of the message.
 * @returns {Object} - The mos message object.
 */
function createBaseMOSMessage(mosID, ncsID, messageContent) {
    return {
        mos: {
            mosID: mosID,
            ncsID: ncsID,
            ...messageContent
        }
    };
}

// QIMERA data to item parser
// TODO: Pass all the parser functions to a separate file
/**
 * Parses switcher trigger data and maps it into the itemData structure.
 * 
 * @param {Object} switcherData - All the switcher data that contains the trigger data.
 * @param {string} mosID - The MOS ID to be used in the itemData.
 * @returns {Object} - The itemData object for generating a MOS message.
 */
function parseTriggerDataToItem(switcherData, mosID) {
    // Extracting the relevant data fields from switcherData
    const triggerData = switcherData.moduleData.data;
    
    // Create and return the itemData object based on the parsed switcher data
    const itemData = {
        itemID: '0',  // Placeholder for itemID
        itemSlug: `slug:${triggerData.categoryID}/${triggerData.buttonName}`,  // Example slug
        itemType: 'Trigger',  // Example itemType
        objID: `OBJ_${triggerData.categoryID}_${triggerData.triggerName}`,  // Example objID
        mosID: mosID || 'default.mos.server.com',  // Use passed mosID or default value
        mosPlugInID: 'Plugin.Switcher',  // Example mosPlugInID
        mosAbstract: `Trigger: ${triggerData.buttonName} from Category: ${triggerData.categoryID}`,  // Abstract description
        objPaths: [
            {
                techDescription: 'Switcher Trigger Path',
                path: `/${triggerData.categoryID}/${triggerData.triggerName}`
            }
        ],
        itemChannel: 'A',  // Default channel
        itemEdStart: 0,  // Default start time
        itemEdDur: 1000,  // Example duration
        itemTrigger: triggerData.triggerName,  // Map triggerName to itemTrigger
        mosExternalMetadata: {
            scope: 'STORY',
            schema: 'http://example.com/mos/supported_schemas/TriggerSchema',
            payload: {
                triggerName: triggerData.triggerName,
                triggerID: triggerData.triggerID,
                categoryID: triggerData.categoryID,
                sceneID: triggerData.sceneID,
                eventType: switcherData.type,
                module: switcherData.module,
                subModule: switcherData.moduleData.subModule,
                instanceId: switcherData.instanceId  // Including instanceId from switcherData
            }
        }
    };

    return itemData;
}

////////////////////////////////////////////////////////////////////////////////////////



// ro (Running Order) family of messages. see (https://mosprotocol.com/wp-content/MOS-Protocol-Documents/MOS-Protocol-2.8.4-Current.htm#mos40)

/**
 * roAck - Create a RO ack message object.
 * @param {string} mosID - The mosID of the sender.
 * @param {string} ncsID - The ncsID of the sender.
 * @param {string} roID - The roID of the message.
 * @param {string} roStatus - The roStatus of the message.
 * @returns {Object} - The mos ack message object.
 */
function mosMessage_MOSAck(mosID, ncsID, roID, roStatus) {
    return createBaseMOSMessage(mosID, ncsID, {
        roAck: {
            roID: roID,
            roStatus: roStatus
        }
    });
}

/**
 * roCreate - Create a RO create message object.
 * @param {string} mosID - The mosID of the sender.
 * @param {string} ncsID - The ncsID of the sender.
 * @param {Object} roCreate - The roCreate content of the message
 * 
 * @returns {Object} - The mos create message object.
 */
function mosMessage_ROCreate(mosID, ncsID, roCreate) {
    return {
        mos: {
            mosID: mosID,
            ncsID: ncsID,
            messageId: createMessageId(),
            ...roCreate
        }
    };
}


// MOS-ActiveX Control Specification


// ncsItem
/**
 * ncsItem - Create a ncsItem message object.
 * Allows either the ActiveX Plug-In or NCS Host to send an Item Reference to the other application
 * @param {string} mosID - The mosID of the sender.
 * @param {string} ncsID - The ncsID of the sender.
 * @param {string} itemData - The json data of the item. (can contain an fields and values)
 */
function mosMessage_NCSItem(itemData) {

    return {
        mos: {
            ncsItem: {
                item: itemData
            }
        }
    };
}


module.exports = {
    createBaseMOSMessage,

    // ro (Running Order) family of messages
    mosMessage_MOSAck,
    mosMessage_ROCreate,

    // 
    mosMessage_NCSItem,

    // TODO: Remove the parser functions from here
    parseTriggerDataToItem

};