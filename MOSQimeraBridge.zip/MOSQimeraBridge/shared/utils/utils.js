
/**
 * @breif Convert hex color to rgba color
 * Example: hexToRgba('ffffffff') or hexToRgba('#ffffffff') or hexToRgba('0xffffffff')
 * Alpha is optional in the hex color
 * 
 * @param {*} hex 
 * @returns 
 */
const hexToRgba = (hex) => {
    let hexColor = hex.replace('#', '');
    if (hexColor.length === 6) {
        hexColor = 'ff' + hexColor;
    }
    const r = parseInt(hexColor.substring(0, 2), 16);
    const g = parseInt(hexColor.substring(2, 4), 16);
    const b = parseInt(hexColor.substring(4, 6), 16);
    const a = parseInt(hexColor.substring(6, 8), 16) / 255;
    return `rgba(${r}, ${g}, ${b}, ${a})`;
};

module.exports = {
    hexToRgba
};