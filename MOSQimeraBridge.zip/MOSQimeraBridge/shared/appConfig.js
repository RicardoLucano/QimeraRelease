// config.js
const fs = require('fs');
const path = require('path');

let config = {};

try {
    config  = require('../config.json');
    console.log("Config loaded successfully:", config);
} catch (err) {
    console.error("Failed to load config:", err.message);
    process.exit(1); // or fallback to defaults if needed
}

module.exports = {
    // Qimera main service configuration.
    MAIN_QIMERA_TCP_PORT: config.mainService.qimeraTcpPort
        ? config.mainService.qimeraTcpPort
        : 3002,
    MAIN_WS_PORT: config.mainService.wsPort
        ? config.mainService.wsPort
        : 8080,

    // MOS Configuration
    MOS_IP: config.mos.ip
        ? config.mos.ip
        : '',
    MOS_LOWER_PORT: config.mos.lowerPort
        ? config.mos.lowerPort
        : 10540,
    MOS_UPPER_PORT: config.mos.upperPort
        ? config.mos.upperPort
        : 10541,

    RO_SERVER_PORT: config.roServerPort
        ? config.roServerPort
        : 3003,

    // Web client socket configuration.
    WEB_CLIENT_PORT: config.webClientPort
        ? config.webClientPort
        : 3000,

    WS_MAIN_SERVER_URL: config.wsMain.url
        ? config.wsMain.url
        : 'ws://127.0.0.1',
    WS_MAIN_SERVER_PORT: config.wsMain.port
        ? config.wsMain.port
        : 8080,

    WS_RO_SERVER_URL: config.wsRo.url
        ? config.wsRo.url
        : 'ws://127.0.0.1',
    WS_RO_SERVER_PORT: config.wsRo.port
        ? config.wsRo.port
        : 3003,
};


